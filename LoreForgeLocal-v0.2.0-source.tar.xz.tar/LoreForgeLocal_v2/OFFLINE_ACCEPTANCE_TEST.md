# Offline Acceptance Test

Run this on a physical ARM64 Android device before calling a build release-verified.

1. Install the APK.
2. Confirm the app opens without login or registration.
3. Create a story and a few Story Bible entries with no model installed.
4. Open Model Manager and import a compatible GGUF through Android's document picker.
5. Inspect the model card and confirm size/architecture/quantization/context metadata where present.
6. Load the model. Record the hardware estimate and verify the UI remains responsive during loading.
7. Generate a story continuation and confirm text appears incrementally rather than all at once.
8. Start a longer generation, press STOP, and confirm the already streamed text remains in the story and is editable.
9. Enable Airplane Mode.
10. Explicitly leave Wi-Fi disabled and mobile data disabled.
11. Force-stop LoreForge Local from Android settings.
12. Relaunch the application.
13. Load the existing story and Story Bible.
14. Continue generating with the same local GGUF.
15. Edit the story and verify autosave after relaunch.
16. Create and switch a branch.
17. Run story search.
18. Regenerate and create an alternative generation.
19. Export the story with Android's document picker.
20. Import a text/Markdown story locally.
21. Force-stop and relaunch again while still offline.
22. Continue generation again.
23. Inspect the installed APK permissions with Android settings or `aapt dump permissions`; `android.permission.INTERNET` must be absent.
24. Confirm no story content is visible in network captures because the application has no socket permission.

Record device model, Android version, GGUF filename, quantization, context size, and pass/fail notes for the release artifact.
