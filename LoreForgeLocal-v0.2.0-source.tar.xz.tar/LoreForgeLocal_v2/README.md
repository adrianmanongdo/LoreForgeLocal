# LoreForge Local

LoreForge Local is an Android interactive-fiction application designed around **real on-device GGUF inference**. The primary story path has no cloud AI provider, no developer inference server, no account, no subscription, no moderation API, and no required network connection.

## Architecture

```
Android Compose UI
    ↓
Story Repository / Story Engine
    ↓
Context Assembly Engine
    ↓
Local Memory Retrieval + Story Bible
    ↓
Prompt Formatter
    ↓
LocalStoryModel abstraction
    ↓
LlamaCppModel
    ↓
Kotlin/JNI Android AAR
    ↓
llama.cpp / GGML
    ↓
User-selected GGUF file
```

The packaged runtime dependency is `org.codeshipping:llama-kotlin-android:0.1.7`. It wraps native llama.cpp, exposes Kotlin coroutine/Flow token streaming, and provides native cancellation. The app itself contains no canned story generator and no HTTP AI client.

## Privacy guarantees in this release

- `android.permission.INTERNET` is force-removed in the manifest, including from transitive library manifests.
- Android backup is disabled so the Room database is not silently cloud-backed-up by the OS.
- No analytics SDK.
- No advertising SDK.
- No remote crash-reporting SDK.
- No account/login SDK.
- No remote moderation SDK.
- No story/prompt telemetry.
- No automatic model downloader.
- Story projects, Story Bible, branches, memory, settings, and model metadata are stored locally with Room/SQLite.

## Implemented features

### Story workspace
- project create/rename/delete
- full story editing
- autosave
- undo / redo
- user direction input after any amount of story text
- real incremental token streaming
- native STOP with partial-output preservation
- regenerate
- alternative generation with previous result saved as a branch
- branches
- local full-text occurrence search
- text/Markdown import
- Markdown export

### Story Bible and memory
- characters
- locations
- objects
- relationships
- timeline/events
- generic canon categories
- persistent Room storage
- local lexical relevance retrieval
- recent-story context window assembly

### Model Manager
- SAF `ACTION_OPEN_DOCUMENT` model picking through `ActivityResultContracts.OpenDocument`
- persisted read URI permission where the provider supports it
- `.gguf` validation
- local GGUF header/metadata inspection without loading model tensors
- rename display name independently of filename
- activate / switch / reload
- unload
- remove
- replace source model
- app-managed copy option
- original-document URI option using an open file descriptor exposed to native code through `/proc/self/fd/<fd>`
- file-size/storage warning before copying
- model profiles
- imported / last-used timestamps

### GGUF metadata shown where available
- friendly name
- original filename
- file size
- GGUF version
- architecture
- parameter count (metadata or summed tensor dimensions)
- quantization/file type
- tokenizer metadata
- trained context length
- embedded chat template presence
- rope-related metadata
- tensor count
- source URI/path
- storage mode

### Model loading and hardware estimate
- total device RAM
- currently available RAM
- model file size
- context configuration
- approximate KV-cache requirement
- runtime/application overhead estimate
- ratings: EXCELLENT / SHOULD RUN / HEAVY / VERY HEAVY / LIKELY TOO LARGE
- LOAD ANYWAY remains available
- lower-context action

### Prompt system
- visible/editable application system prompt
- reset to default
- optional profile-level system-prompt override
- optional story-level system-prompt override
- hierarchy: application → active profile → story
- Auto / GGUF-detected / ChatML / Llama 3 / Gemma / Mistral / Alpaca / Raw / Custom
- validated custom template variables

### Settings exposed by the current native binding
- temperature
- top P
- top K
- repeat penalty
- maximum generation tokens
- CPU thread count
- context length
- batch size
- mmap
- mlock
- seed through saved profiles/config
- human-friendly creativity, response-length, and performance presets

Controls that the packaged runtime does not reliably expose are deliberately not shown as functional controls.

## Important runtime notes

The baseline packaged runtime is CPU/ARM-NEON. GPU/Vulkan/Flash-Attention controls are not advertised because this dependency does not document those paths as reliable in its packaged Android AAR.

The app reads the GGUF chat-template metadata and recognizes common formats. The current AAR's documented public Kotlin API does not expose generic evaluation of every arbitrary embedded Jinja chat template or model tokenization, so the capability layer reports those two items as unavailable instead of faking them. A future native adapter can implement those methods without changing the Story Engine because the application depends on the `LocalStoryModel` abstraction.

## Build

Requirements:

- JDK 17+
- Android SDK Platform 36
- Android Build Tools 36.0.0+
- Gradle 8.13
- Android Gradle Plugin 8.13.2
- Internet access **only during compilation** to resolve Maven dependencies; the built app does not need it.

From a configured workstation:

```bash
gradle :app:assembleDebug
```

Output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`; it builds the APK and fails if the final merged APK declares `android.permission.INTERNET`.

## Offline acceptance test

See `OFFLINE_ACCEPTANCE_TEST.md`. The APK should only be marked release-verified after that checklist has been executed on a physical ARM64 Android device with a compatible GGUF model.

## No model bundled

There is intentionally no LLM inside the application package. The UI works without one. Generation shows the required local-model message until a GGUF file is imported and selected.
