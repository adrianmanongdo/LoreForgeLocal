#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/verify_source_privacy.sh
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.13 is required. Open this project in Android Studio or install Gradle 8.13." >&2
  exit 2
fi
gradle :app:assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || { echo "Build completed without expected APK: $APK" >&2; exit 3; }
echo "$APK"
