#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"

echo "Checking manifest network permission removal..."
grep -q 'android.permission.INTERNET.*tools:node="remove"' "$MANIFEST"

echo "Checking that common cloud/analytics AI SDKs were not added..."
if grep -RniE 'com\.openai|anthropic|gemini|openrouter|replicate|together\.ai|groq|firebase-analytics|crashlytics|sentry|amplitude|mixpanel' "$ROOT/app" --exclude='*.md'; then
  echo "Unexpected remote/cloud/analytics dependency marker found." >&2
  exit 1
fi

echo "Checking that no bundled GGUF exists..."
if find "$ROOT/app/src" -type f -iname '*.gguf' | grep -q .; then
  echo "A GGUF model is bundled in app/src; this is prohibited." >&2
  exit 1
fi

echo "Source privacy checks passed."
