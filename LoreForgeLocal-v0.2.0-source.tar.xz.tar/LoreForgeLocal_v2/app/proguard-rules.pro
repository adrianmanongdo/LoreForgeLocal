# Keep JNI-facing classes from the llama.cpp Android binding.
-keep class org.codeshipping.llamakotlin.** { *; }
