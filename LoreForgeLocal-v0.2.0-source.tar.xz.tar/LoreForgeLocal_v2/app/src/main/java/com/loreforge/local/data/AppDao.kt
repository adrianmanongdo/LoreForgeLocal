package com.loreforge.local.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM stories ORDER BY updatedAt DESC") fun observeStories(): Flow<List<StoryEntity>>
    @Query("SELECT * FROM stories WHERE id=:id") suspend fun story(id: Long): StoryEntity?
    @Insert suspend fun insertStory(story: StoryEntity): Long
    @Update suspend fun updateStory(story: StoryEntity)
    @Delete suspend fun deleteStory(story: StoryEntity)

    @Query("SELECT * FROM bible_entries WHERE storyId=:storyId ORDER BY pinned DESC, category, name") fun observeBible(storyId: Long): Flow<List<BibleEntryEntity>>
    @Query("SELECT * FROM bible_entries WHERE storyId=:storyId") suspend fun bible(storyId: Long): List<BibleEntryEntity>
    @Insert suspend fun insertBible(entry: BibleEntryEntity): Long
    @Update suspend fun updateBible(entry: BibleEntryEntity)
    @Delete suspend fun deleteBible(entry: BibleEntryEntity)

    @Query("SELECT * FROM memories WHERE storyId=:storyId ORDER BY createdAt DESC") suspend fun memories(storyId: Long): List<MemoryEntity>
    @Insert suspend fun insertMemory(memory: MemoryEntity): Long
    @Query("DELETE FROM memories WHERE storyId=:storyId AND id NOT IN (SELECT id FROM memories WHERE storyId=:storyId ORDER BY createdAt DESC LIMIT :keep)") suspend fun trimMemories(storyId: Long, keep: Int)

    @Query("SELECT * FROM branches WHERE storyId=:storyId ORDER BY createdAt DESC") fun observeBranches(storyId: Long): Flow<List<BranchEntity>>
    @Insert suspend fun insertBranch(branch: BranchEntity): Long
    @Query("SELECT * FROM branches WHERE id=:id") suspend fun branch(id: Long): BranchEntity?
    @Delete suspend fun deleteBranch(branch: BranchEntity)

    @Query("SELECT * FROM models ORDER BY active DESC, lastUsedAt DESC, importedAt DESC") fun observeModels(): Flow<List<ModelEntity>>
    @Query("SELECT * FROM models WHERE active=1 LIMIT 1") suspend fun activeModel(): ModelEntity?
    @Query("SELECT * FROM models WHERE id=:id") suspend fun model(id: Long): ModelEntity?
    @Insert suspend fun insertModel(model: ModelEntity): Long
    @Update suspend fun updateModel(model: ModelEntity)
    @Delete suspend fun deleteModel(model: ModelEntity)
    @Query("UPDATE models SET active=0") suspend fun clearActiveModels()
    @Query("UPDATE models SET active=1, lastUsedAt=:now WHERE id=:id") suspend fun activateModel(id: Long, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM model_profiles WHERE modelId=:modelId ORDER BY active DESC, name") fun observeProfiles(modelId: Long): Flow<List<ModelProfileEntity>>
    @Query("SELECT * FROM model_profiles WHERE modelId=:modelId AND active=1 LIMIT 1") suspend fun activeProfile(modelId: Long): ModelProfileEntity?
    @Insert suspend fun insertProfile(profile: ModelProfileEntity): Long
    @Update suspend fun updateProfile(profile: ModelProfileEntity)
    @Delete suspend fun deleteProfile(profile: ModelProfileEntity)
    @Query("UPDATE model_profiles SET active=0 WHERE modelId=:modelId") suspend fun clearActiveProfiles(modelId: Long)
    @Query("UPDATE model_profiles SET active=1 WHERE id=:id") suspend fun activateProfile(id: Long)

    @Query("SELECT * FROM settings WHERE `key`=:key") suspend fun setting(key: String): SettingEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSetting(setting: SettingEntity)
}
