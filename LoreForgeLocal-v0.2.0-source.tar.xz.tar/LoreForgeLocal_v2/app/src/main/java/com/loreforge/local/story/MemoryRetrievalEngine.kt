package com.loreforge.local.story

import com.loreforge.local.data.MemoryEntity
import kotlin.math.ln

/** Fully local lexical memory retrieval; story text never leaves the device. */
class MemoryRetrievalEngine {
    fun retrieve(query: String, memories: List<MemoryEntity>, maxItems: Int = 10): List<MemoryEntity> {
        val q = terms(query)
        if (q.isEmpty()) return memories.sortedByDescending { it.createdAt }.take(maxItems)
        val now = System.currentTimeMillis()
        return memories.map { m ->
            val mt = terms(m.text)
            val overlap = q.sumOf { term -> if (term in mt) 1.0 else 0.0 }
            val recencyDays = ((now - m.createdAt).coerceAtLeast(0L) / 86_400_000.0)
            val recency = 1.0 / (1.0 + ln(1.0 + recencyDays))
            m to (overlap * 3.0 + m.importance * 0.65 + recency)
        }.filter { it.second > 0.5 }.sortedByDescending { it.second }.take(maxItems).map { it.first }
    }

    private fun terms(s: String) = Regex("[\\p{L}\\p{N}_'-]{3,}").findAll(s.lowercase()).map { it.value }.toSet()
}
