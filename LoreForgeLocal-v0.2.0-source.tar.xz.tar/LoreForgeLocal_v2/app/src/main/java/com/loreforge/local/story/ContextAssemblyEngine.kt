package com.loreforge.local.story

import com.loreforge.local.data.BibleEntryEntity
import com.loreforge.local.data.MemoryEntity
import com.loreforge.local.data.StoryEntity
import com.loreforge.local.model.StoryContext

class ContextAssemblyEngine(private val memoryEngine: MemoryRetrievalEngine = MemoryRetrievalEngine()) {
    fun assemble(
        story: StoryEntity,
        bible: List<BibleEntryEntity>,
        memories: List<MemoryEntity>,
        systemPrompt: String,
        instruction: String,
        targetContextTokens: Int
    ): StoryContext {
        val charsBudget = (targetContextTokens * 3.2).toInt().coerceAtLeast(4_000)
        val reserved = 6_000
        val recentStory = story.body.takeLast((charsBudget - reserved).coerceAtLeast(2_000))
        val relevant = memoryEngine.retrieve("$instruction ${story.body.takeLast(1500)}", memories)
        fun lines(category: String? = null) = bible.filter { category == null || it.category.equals(category, true) }
            .joinToString("\n") { "- ${it.name}: ${it.content}" }
        val special = setOf("character", "characters", "timeline", "event")
        val general = bible.filter { it.category.lowercase() !in special }.joinToString("\n") { "- [${it.category}] ${it.name}: ${it.content}" }
        return StoryContext(
            systemPrompt = systemPrompt,
            storyBible = general,
            characters = bible.filter { it.category.lowercase() in setOf("character", "characters") }.joinToString("\n") { "- ${it.name}: ${it.content}" },
            timeline = bible.filter { it.category.lowercase() in setOf("timeline", "event") }.joinToString("\n") { "- ${it.name}: ${it.content}" },
            memory = relevant.joinToString("\n") { "- ${it.text}" },
            recentStory = recentStory,
            userInstruction = instruction
        )
    }
}
