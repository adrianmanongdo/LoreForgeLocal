package com.loreforge.local.model

enum class GenerationState { Idle, PreparingContext, Tokenizing, Generating, Stopping, Completed, Cancelled, Failed }
enum class StorageMode { ORIGINAL_URI, APP_MANAGED_COPY }
enum class PromptTemplateKind { AUTO, GGUF_DETECTED, CHATML, LLAMA3, GEMMA, MISTRAL, ALPACA, RAW, CUSTOM }
enum class CreativityPreset { PRECISE, BALANCED, CREATIVE, WILD, CUSTOM }
enum class ResponseLengthPreset { ONE_SENTENCE, TWO_SENTENCES, SHORT, MEDIUM, LONG, CUSTOM }
enum class PerformancePreset { AUTO, BATTERY_SAVER, BALANCED, MAXIMUM_SPEED, CUSTOM }
enum class HardwareRating { EXCELLENT, SHOULD_RUN, HEAVY, VERY_HEAVY, LIKELY_TOO_LARGE }

data class ModelDescriptor(
    val id: Long = 0,
    val displayName: String,
    val originalFilename: String,
    val uri: String?,
    val localPath: String?,
    val fileSizeBytes: Long,
    val architecture: String?,
    val parameterCount: Long?,
    val quantization: String?,
    val ggufVersion: Int?,
    val tokenizer: String?,
    val contextCapacity: Int?,
    val embeddedChatTemplate: String?,
    val ropeInfo: String?,
    val tensorCount: Long?,
    val storageMode: StorageMode,
    val importedAt: Long,
    val lastUsedAt: Long?,
    val active: Boolean
)

data class ModelLoadConfig(
    val temperature: Float = 0.8f,
    val topP: Float = 0.95f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.1f,
    val maxGenerationTokens: Int = 256,
    val cpuThreads: Int = Runtime.getRuntime().availableProcessors().coerceAtLeast(1),
    val contextLength: Int = 4096,
    val batchSize: Int = 256,
    val gpuLayers: Int = 0,
    val useMmap: Boolean = true,
    val useMlock: Boolean = false,
    val seed: Int = -1,
    val creativityPreset: CreativityPreset = CreativityPreset.BALANCED,
    val responseLengthPreset: ResponseLengthPreset = ResponseLengthPreset.SHORT,
    val performancePreset: PerformancePreset = PerformancePreset.AUTO,
)

data class ModelCapabilities(
    val cpu: Boolean = true,
    val neon: Boolean = true,
    val gpuOffload: Boolean = false,
    val vulkan: Boolean = false,
    val flashAttention: Boolean = false,
    val tokenization: Boolean = false,
    val embeddedChatTemplateApplication: Boolean = false,
    val supportedSettings: Set<String> = setOf(
        "temperature", "topP", "topK", "repeatPenalty", "maxTokens", "threads",
        "contextLength", "batchSize", "gpuLayers", "useMmap", "useMlock", "seed"
    )
)

data class GenerationRequest(
    val prompt: String,
    val config: ModelLoadConfig
)

sealed interface GenerationEvent {
    data class State(val state: GenerationState) : GenerationEvent
    data class Token(val text: String) : GenerationEvent
    data class Error(val message: String, val cause: Throwable? = null) : GenerationEvent
    data object Done : GenerationEvent
}

data class StoryContext(
    val systemPrompt: String,
    val storyBible: String,
    val characters: String,
    val timeline: String,
    val memory: String,
    val recentStory: String,
    val userInstruction: String,
    val assistantPrefix: String = ""
)

data class HardwareEstimate(
    val modelBytes: Long,
    val estimatedMinBytes: Long,
    val estimatedMaxBytes: Long,
    val totalRamBytes: Long,
    val availableRamBytes: Long,
    val kvCacheBytes: Long,
    val rating: HardwareRating,
    val explanation: String
)
