package com.loreforge.local.inference

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import java.io.InputStream
import java.io.EOFException
import kotlin.math.max

data class GgufMetadata(
    val version: Int,
    val tensorCount: Long,
    val architecture: String?,
    val name: String?,
    val parameterCount: Long?,
    val quantization: String?,
    val tokenizer: String?,
    val contextLength: Int?,
    val chatTemplate: String?,
    val ropeInfo: String?,
    val vocabularySize: Long?
)

/** Lightweight GGUF header/tensor-info inspector. It never loads tensor payloads. */
object GgufMetadataReader {
    private const val MAX_TEXT_BYTES = 4L * 1024 * 1024


    /**
     * SAF-friendly metadata reader. Unlike the FileChannel inspector, this only walks GGUF metadata
     * sequentially and never parses tensor descriptors. A 1 MiB BufferedInputStream at the call site
     * makes large tokenizer arrays practical even on Android document providers.
     */
    fun read(input: InputStream): GgufMetadata {
        val r = StreamReader(input)
        val magic = ByteArray(4)
        r.readFully(magic)
        require(String(magic, Charsets.US_ASCII) == "GGUF") { "Not a GGUF file (missing GGUF magic)." }

        val version = r.u32().toInt()
        require(version in 1..10) { "Unsupported GGUF version: $version" }
        val tensorCount = r.u64()
        val metadataCount = r.u64()
        require(tensorCount in 0..10_000_000L && metadataCount in 0..10_000_000L) { "Invalid GGUF header counts." }

        val scalars = linkedMapOf<String, Any?>()
        var vocabSize: Long? = null
        repeat(metadataCount.toInt()) {
            val key = r.string(collect = true) ?: ""
            val type = r.u32().toInt()
            if (type == 9) {
                val elemType = r.u32().toInt()
                val count = r.u64()
                if (key == "tokenizer.ggml.tokens") vocabSize = count
                r.skipArray(elemType, count)
            } else {
                val collect = key == "general.architecture" ||
                    key == "general.name" ||
                    key == "general.file_type" ||
                    key == "general.parameter_count" ||
                    key == "tokenizer.ggml.model" ||
                    key == "tokenizer.ggml.pre" ||
                    key == "tokenizer.chat_template" ||
                    key.endsWith(".context_length") ||
                    key.contains(".rope.") ||
                    key.contains("rope.scaling")
                val value = r.readScalar(type, collect)
                if (collect) scalars[key] = value
            }
        }

        val arch = scalars["general.architecture"] as? String
        val contextKey = scalars.keys.firstOrNull { it.endsWith(".context_length") }
        val context = (contextKey?.let { numericLong(scalars[it]) })?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt()
        val rope = scalars.filterKeys { it.contains(".rope.") || it.contains("rope.scaling") }
            .entries.joinToString(", ") { "${it.key.substringAfter(".")}: ${it.value}" }
            .ifBlank { null }
        val fileType = numericLong(scalars["general.file_type"])?.toInt()

        return GgufMetadata(
            version = version,
            tensorCount = tensorCount,
            architecture = arch,
            name = scalars["general.name"] as? String,
            parameterCount = numericLong(scalars["general.parameter_count"]),
            quantization = quantLabel(fileType),
            tokenizer = listOfNotNull(scalars["tokenizer.ggml.model"] as? String, scalars["tokenizer.ggml.pre"] as? String)
                .distinct().joinToString(" / ").ifBlank { null },
            contextLength = context,
            chatTemplate = scalars["tokenizer.chat_template"] as? String,
            ropeInfo = rope,
            vocabularySize = vocabSize
        )
    }

    private class StreamReader(private val input: InputStream) {
        private val scratch = ByteArray(8)

        fun readFully(dst: ByteArray) {
            var off = 0
            while (off < dst.size) {
                val n = input.read(dst, off, dst.size - off)
                if (n < 0) throw EOFException("Unexpected end of GGUF file")
                off += n
            }
        }

        private fun readN(n: Int): ByteArray {
            var off = 0
            while (off < n) {
                val got = input.read(scratch, off, n - off)
                if (got < 0) throw EOFException("Unexpected end of GGUF file")
                off += got
            }
            return scratch
        }

        fun u8(): Int = input.read().also { if (it < 0) throw EOFException("Unexpected end of GGUF file") }
        fun i8(): Byte = u8().toByte()
        fun u16(): Int { val b=readN(2); return (b[0].toInt() and 0xff) or ((b[1].toInt() and 0xff) shl 8) }
        fun i16(): Short = u16().toShort()
        fun u32(): Long {
            val b=readN(4)
            return ((b[0].toLong() and 0xff) or ((b[1].toLong() and 0xff) shl 8) or ((b[2].toLong() and 0xff) shl 16) or ((b[3].toLong() and 0xff) shl 24)) and 0xffffffffL
        }
        fun i32(): Int = u32().toInt()
        private fun raw64(): Long {
            val b=readN(8)
            var v=0L
            for (i in 0..7) v = v or ((b[i].toLong() and 0xff) shl (8*i))
            return v
        }
        fun u64(): Long = raw64().also { require(it >= 0) { "Unsigned 64-bit GGUF value exceeds supported range" } }
        fun i64(): Long = raw64()
        fun f32(): Float = Float.fromBits(u32().toInt())
        fun f64(): Double = Double.fromBits(raw64())

        fun readScalar(type: Int, collect: Boolean): Any? = when(type) {
            0 -> u8().let { if (collect) it else null }
            1 -> i8().let { if (collect) it else null }
            2 -> u16().let { if (collect) it else null }
            3 -> i16().let { if (collect) it else null }
            4 -> u32().let { if (collect) it else null }
            5 -> i32().let { if (collect) it else null }
            6 -> f32().let { if (collect) it else null }
            7 -> u8().let { if (collect) it != 0 else null }
            8 -> string(collect)
            10 -> u64().let { if (collect) it else null }
            11 -> i64().let { if (collect) it else null }
            12 -> f64().let { if (collect) it else null }
            else -> error("Unsupported GGUF metadata value type: $type")
        }

        fun skipArray(elementType: Int, count: Long) {
            require(count in 0..100_000_000L) { "GGUF array is unreasonably large." }
            if (elementType == 8) {
                var i=0L
                while (i<count) { string(collect=false); i++ }
                return
            }
            if (elementType == 9) error("Nested GGUF arrays are not supported by the format")
            val size = when(elementType) {
                0,1,7 -> 1L
                2,3 -> 2L
                4,5,6 -> 4L
                10,11,12 -> 8L
                else -> error("Unsupported GGUF array type: $elementType")
            }
            skipFully(Math.multiplyExact(size, count))
        }

        fun string(collect: Boolean): String? {
            val len=u64()
            require(len >= 0 && len <= Int.MAX_VALUE.toLong()) { "Invalid GGUF string length: $len" }
            if (!collect || len > MAX_TEXT_BYTES) { skipFully(len); return null }
            val bytes=ByteArray(len.toInt())
            readFully(bytes)
            return String(bytes, Charsets.UTF_8)
        }

        private fun skipFully(bytes: Long) {
            var remaining=bytes
            while (remaining>0) {
                val skipped=input.skip(remaining)
                if (skipped>0) { remaining-=skipped; continue }
                if (input.read() < 0) throw EOFException("Unexpected end of GGUF file")
                remaining--
            }
        }
    }

    fun read(channel: FileChannel): GgufMetadata {
        channel.position(0)
        val magic = ByteArray(4)
        readFully(channel, ByteBuffer.wrap(magic))
        require(String(magic, Charsets.US_ASCII) == "GGUF") { "Not a GGUF file (missing GGUF magic)." }

        val version = u32(channel).toInt()
        require(version in 1..10) { "Unsupported GGUF version: $version" }
        val tensorCount = u64(channel)
        val metadataCount = u64(channel)
        require(tensorCount in 0..10_000_000L && metadataCount in 0..10_000_000L) { "Invalid GGUF header counts." }

        val scalars = linkedMapOf<String, Any?>()
        var vocabSize: Long? = null

        repeat(metadataCount.toInt()) {
            val key = string(channel, collect = true) ?: ""
            val type = u32(channel).toInt()
            if (type == 9) {
                val elemType = u32(channel).toInt()
                val count = u64(channel)
                if (key == "tokenizer.ggml.tokens") vocabSize = count
                skipArray(channel, elemType, count)
            } else {
                val collect = key == "general.architecture" ||
                    key == "general.name" ||
                    key == "general.file_type" ||
                    key == "general.parameter_count" ||
                    key == "tokenizer.ggml.model" ||
                    key == "tokenizer.ggml.pre" ||
                    key == "tokenizer.chat_template" ||
                    key.endsWith(".context_length") ||
                    key.contains(".rope.") ||
                    key.contains("rope.scaling")
                val value = readScalar(channel, type, collect)
                if (collect) scalars[key] = value
            }
        }

        // GGUF tensor infos immediately follow metadata. Sum dimensions to obtain a real
        // parameter count when general.parameter_count is absent.
        var summedParams = 0L
        var tensorParseOk = true
        repeat(tensorCount.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()) {
            try {
                string(channel, collect = false)
                val nDims = u32(channel).toInt()
                require(nDims in 0..16)
                var elements = 1L
                repeat(nDims) {
                    val d = u64(channel)
                    if (d <= 0 || elements > Long.MAX_VALUE / max(1L, d)) {
                        tensorParseOk = false
                    } else if (tensorParseOk) {
                        elements *= d
                    }
                }
                u32(channel) // ggml tensor type
                u64(channel) // tensor data offset
                if (tensorParseOk && summedParams <= Long.MAX_VALUE - elements) summedParams += elements
            } catch (_: Throwable) {
                tensorParseOk = false
                return@repeat
            }
        }

        val arch = scalars["general.architecture"] as? String
        val contextKey = scalars.keys.firstOrNull { it.endsWith(".context_length") }
        val context = (contextKey?.let { numericLong(scalars[it]) })?.coerceAtMost(Int.MAX_VALUE.toLong())?.toInt()
        val rope = scalars.filterKeys { it.contains(".rope.") || it.contains("rope.scaling") }
            .entries.joinToString(", ") { "${it.key.substringAfter(".")}: ${it.value}" }
            .ifBlank { null }
        val fileType = numericLong(scalars["general.file_type"])?.toInt()
        val paramScalar = numericLong(scalars["general.parameter_count"])
        val params = paramScalar ?: if (tensorParseOk && summedParams > 0) summedParams else null

        return GgufMetadata(
            version = version,
            tensorCount = tensorCount,
            architecture = arch,
            name = scalars["general.name"] as? String,
            parameterCount = params,
            quantization = quantLabel(fileType),
            tokenizer = listOfNotNull(scalars["tokenizer.ggml.model"] as? String, scalars["tokenizer.ggml.pre"] as? String)
                .distinct().joinToString(" / ").ifBlank { null },
            contextLength = context,
            chatTemplate = scalars["tokenizer.chat_template"] as? String,
            ropeInfo = rope,
            vocabularySize = vocabSize
        )
    }

    private fun numericLong(v: Any?): Long? = when (v) {
        is Byte -> v.toLong(); is Short -> v.toLong(); is Int -> v.toLong(); is Long -> v
        is Float -> v.toLong(); is Double -> v.toLong(); else -> null
    }

    private fun readScalar(channel: FileChannel, type: Int, collect: Boolean): Any? = when (type) {
        0 -> u8(channel).let { if (collect) it else null }
        1 -> i8(channel).let { if (collect) it else null }
        2 -> u16(channel).let { if (collect) it else null }
        3 -> i16(channel).let { if (collect) it else null }
        4 -> u32(channel).let { if (collect) it else null }
        5 -> i32(channel).let { if (collect) it else null }
        6 -> f32(channel).let { if (collect) it else null }
        7 -> u8(channel).let { if (collect) it != 0 else null }
        8 -> string(channel, collect)
        10 -> u64(channel).let { if (collect) it else null }
        11 -> i64(channel).let { if (collect) it else null }
        12 -> f64(channel).let { if (collect) it else null }
        else -> error("Unsupported GGUF metadata value type: $type")
    }

    private fun skipArray(channel: FileChannel, elementType: Int, count: Long) {
        require(count in 0..100_000_000L) { "GGUF array is unreasonably large." }
        if (elementType == 8) {
            repeat(count.toInt()) { string(channel, collect = false) }
            return
        }
        if (elementType == 9) error("Nested GGUF arrays are not supported by the format")
        val size = when (elementType) {
            0, 1, 7 -> 1L
            2, 3 -> 2L
            4, 5, 6 -> 4L
            10, 11, 12 -> 8L
            else -> error("Unsupported GGUF array type: $elementType")
        }
        val bytes = Math.multiplyExact(size, count)
        channel.position(channel.position() + bytes)
    }

    private fun string(channel: FileChannel, collect: Boolean): String? {
        val len = u64(channel)
        require(len >= 0 && len <= Int.MAX_VALUE.toLong()) { "Invalid GGUF string length: $len" }
        if (!collect || len > MAX_TEXT_BYTES) {
            channel.position(channel.position() + len)
            return null
        }
        val bytes = ByteArray(len.toInt())
        readFully(channel, ByteBuffer.wrap(bytes))
        return String(bytes, Charsets.UTF_8)
    }

    private fun quantLabel(fileType: Int?): String? = when (fileType) {
        null -> null
        0 -> "F32"; 1 -> "F16"; 2 -> "Q4_0"; 3 -> "Q4_1"; 6 -> "Q5_0"; 7 -> "Q5_1"; 8 -> "Q8_0"
        10 -> "Q2_K"; 11 -> "Q3_K_S"; 12 -> "Q3_K_M"; 13 -> "Q3_K_L"; 14 -> "Q4_K_S"; 15 -> "Q4_K_M"
        16 -> "Q5_K_S"; 17 -> "Q5_K_M"; 18 -> "Q6_K"; 19 -> "IQ2_XXS"; 20 -> "IQ2_XS"; 21 -> "IQ3_XXS"
        22 -> "IQ1_S"; 23 -> "IQ4_NL"; 24 -> "IQ3_S"; 25 -> "IQ2_S"; 26 -> "IQ4_XS"; 27 -> "I8"; 28 -> "I16"
        29 -> "I32"; 30 -> "I64"; 31 -> "F64"; 32 -> "IQ1_M"; 33 -> "BF16"; 34 -> "TQ1_0"; 35 -> "TQ2_0"
        else -> "GGUF file type $fileType"
    }

    private fun readFully(ch: FileChannel, b: ByteBuffer) {
        while (b.hasRemaining()) if (ch.read(b) < 0) error("Unexpected end of GGUF file")
    }
    private fun le(ch: FileChannel, n: Int): ByteBuffer = ByteBuffer.allocate(n).order(ByteOrder.LITTLE_ENDIAN).also { readFully(ch, it); it.flip() }
    private fun u8(ch: FileChannel): Int = le(ch,1).get().toInt() and 0xff
    private fun i8(ch: FileChannel): Byte = le(ch,1).get()
    private fun u16(ch: FileChannel): Int = le(ch,2).short.toInt() and 0xffff
    private fun i16(ch: FileChannel): Short = le(ch,2).short
    private fun u32(ch: FileChannel): Long = le(ch,4).int.toLong() and 0xffffffffL
    private fun i32(ch: FileChannel): Int = le(ch,4).int
    private fun u64(ch: FileChannel): Long { val v = le(ch,8).long; require(v >= 0) { "Unsigned 64-bit GGUF value exceeds supported range" }; return v }
    private fun i64(ch: FileChannel): Long = le(ch,8).long
    private fun f32(ch: FileChannel): Float = le(ch,4).float
    private fun f64(ch: FileChannel): Double = le(ch,8).double
}
