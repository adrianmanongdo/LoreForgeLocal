package com.loreforge.local

import android.app.Application
import androidx.room.Room
import com.loreforge.local.data.AppDatabase
import com.loreforge.local.inference.LlamaCppModel
import com.loreforge.local.story.StoryRepository

class LoreForgeApp : Application() {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "loreforge.db")
            .build()
    }
    val modelRuntime: LlamaCppModel by lazy { LlamaCppModel(this) }
    val repository: StoryRepository by lazy { StoryRepository(this, database.dao(), modelRuntime) }
}
