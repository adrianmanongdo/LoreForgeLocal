package com.loreforge.local.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class StoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val systemPromptOverride: String? = null,
    val activeBranchId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "bible_entries", indices = [Index("storyId")])
data class BibleEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storyId: Long,
    val category: String,
    val name: String,
    val content: String,
    val pinned: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories", indices = [Index("storyId")])
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storyId: Long,
    val text: String,
    val importance: Int = 1,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "branches", indices = [Index("storyId")])
data class BranchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val storyId: Long,
    val name: String,
    val body: String,
    val parentBranchId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val originalFilename: String,
    val uri: String?,
    val localPath: String?,
    val fileSizeBytes: Long,
    val architecture: String?,
    val parameterCount: Long?,
    val quantization: String?,
    val ggufVersion: Int?,
    val tokenizer: String?,
    val contextCapacity: Int?,
    val embeddedChatTemplate: String?,
    val ropeInfo: String?,
    val tensorCount: Long?,
    val storageMode: String,
    val importedAt: Long,
    val lastUsedAt: Long?,
    val active: Boolean = false
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val key: String,
    val value: String
)


@Entity(tableName = "model_profiles", indices = [Index("modelId")])
data class ModelProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: Long,
    val name: String,
    val temperature: Float,
    val topP: Float,
    val topK: Int,
    val repeatPenalty: Float,
    val maxTokens: Int,
    val cpuThreads: Int,
    val contextLength: Int,
    val batchSize: Int,
    val useMmap: Boolean,
    val useMlock: Boolean,
    val seed: Int,
    val systemPromptOverride: String? = null,
    val active: Boolean = false
)
