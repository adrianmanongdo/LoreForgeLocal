package com.loreforge.local.prompt

import com.loreforge.local.model.PromptTemplateKind
import com.loreforge.local.model.StoryContext

class PromptFormatter {
    fun format(
        context: StoryContext,
        requested: PromptTemplateKind,
        embeddedTemplate: String?,
        customTemplate: String?,
        modelName: String? = null,
        architecture: String? = null
    ): String {
        val kind = when (requested) {
            PromptTemplateKind.AUTO -> detectEmbedded(embeddedTemplate) ?: inferFromModel(modelName, architecture) ?: PromptTemplateKind.RAW
            PromptTemplateKind.GGUF_DETECTED -> detectEmbedded(embeddedTemplate)
                ?: throw IllegalArgumentException("The GGUF chat template could not be mapped safely. Choose ChatML, Llama 3, Gemma, Mistral, Alpaca, Raw, or Custom.")
            else -> requested
        }
        val system = context.systemPrompt
        val user = buildUserPayload(context)
        return when (kind) {
            PromptTemplateKind.CHATML -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n${context.assistantPrefix}"
            PromptTemplateKind.LLAMA3 -> "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n$system<|eot_id|><|start_header_id|>user<|end_header_id|>\n\n$user<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n${context.assistantPrefix}"
            PromptTemplateKind.GEMMA -> "<bos><start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n${context.assistantPrefix}"
            PromptTemplateKind.MISTRAL -> "<s>[INST] $system\n\n$user [/INST]${context.assistantPrefix}"
            PromptTemplateKind.ALPACA -> "### Instruction:\n$system\n\n$user\n\n### Response:\n${context.assistantPrefix}"
            PromptTemplateKind.RAW -> "$system\n\n$user\n\nContinue the story:\n${context.assistantPrefix}"
            PromptTemplateKind.CUSTOM -> applyCustom(customTemplate ?: error("Custom template is empty."), context)
            PromptTemplateKind.AUTO, PromptTemplateKind.GGUF_DETECTED -> error("Resolved template cannot remain AUTO")
        }
    }

    fun validateCustom(template: String): Result<Unit> = runCatching {
        require(template.isNotBlank()) { "Custom template cannot be empty." }
        require("{{user_instruction}}" in template || "{{story_context}}" in template) {
            "Custom template must include {{user_instruction}} or {{story_context}}."
        }
        val variables = Regex("\\{\\{([a-z_]+)}}").findAll(template).map { it.groupValues[1] }.toSet()
        val allowed = setOf("system", "story_context", "memory", "story_bible", "characters", "timeline", "user_instruction", "assistant_prefix")
        require(variables.all { it in allowed }) { "Unknown template variable: ${variables.first { it !in allowed }}" }
    }

    fun detectEmbedded(template: String?): PromptTemplateKind? {
        if (template.isNullOrBlank()) return null
        val t = template.lowercase()
        return when {
            "<|start_header_id|>" in t || "<|begin_of_text|>" in t -> PromptTemplateKind.LLAMA3
            "<|im_start|>" in t && "<|im_end|>" in t -> PromptTemplateKind.CHATML
            "<start_of_turn>" in t && "<end_of_turn>" in t -> PromptTemplateKind.GEMMA
            "[inst]" in t && "[/inst]" in t -> PromptTemplateKind.MISTRAL
            "### instruction" in t && "### response" in t -> PromptTemplateKind.ALPACA
            else -> null
        }
    }

    private fun inferFromModel(modelName: String?, architecture: String?): PromptTemplateKind? {
        val hint = listOfNotNull(modelName, architecture).joinToString(" ").lowercase()
        return when {
            "qwen" in hint -> PromptTemplateKind.CHATML
            "llama-3" in hint || "llama3" in hint -> PromptTemplateKind.LLAMA3
            "gemma" in hint -> PromptTemplateKind.GEMMA
            "mistral" in hint || "mixtral" in hint -> PromptTemplateKind.MISTRAL
            else -> null
        }
    }

    private fun buildUserPayload(c: StoryContext) = buildString {
        if (c.storyBible.isNotBlank()) append("STORY BIBLE (persistent canon):\n${c.storyBible}\n\n")
        if (c.characters.isNotBlank()) append("CHARACTERS:\n${c.characters}\n\n")
        if (c.timeline.isNotBlank()) append("TIMELINE:\n${c.timeline}\n\n")
        if (c.memory.isNotBlank()) append("RELEVANT STORY MEMORY:\n${c.memory}\n\n")
        if (c.recentStory.isNotBlank()) append("CURRENT STORY:\n${c.recentStory}\n\n")
        append("USER NARRATIVE DIRECTION:\n${c.userInstruction}")
    }

    private fun applyCustom(template: String, c: StoryContext): String {
        validateCustom(template).getOrThrow()
        val values = mapOf(
            "system" to c.systemPrompt,
            "story_context" to c.recentStory,
            "memory" to c.memory,
            "story_bible" to c.storyBible,
            "characters" to c.characters,
            "timeline" to c.timeline,
            "user_instruction" to c.userInstruction,
            "assistant_prefix" to c.assistantPrefix
        )
        return Regex("\\{\\{([a-z_]+)}}").replace(template) { values[it.groupValues[1]] ?: "" }
    }
}
