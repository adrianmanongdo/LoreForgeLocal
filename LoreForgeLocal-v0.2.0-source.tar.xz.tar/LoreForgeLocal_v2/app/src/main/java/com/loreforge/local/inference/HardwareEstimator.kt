package com.loreforge.local.inference

import android.app.ActivityManager
import android.content.Context
import android.os.StatFs
import com.loreforge.local.model.HardwareEstimate
import com.loreforge.local.model.HardwareRating
import com.loreforge.local.model.ModelDescriptor
import com.loreforge.local.model.ModelLoadConfig
import kotlin.math.max

object HardwareEstimator {
    fun estimate(context: Context, model: ModelDescriptor, config: ModelLoadConfig): HardwareEstimate {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also(am::getMemoryInfo)
        val ctx = config.contextLength.toLong()
        val params = model.parameterCount ?: 0L
        val layers = guessLayers(params)
        val emb = guessEmbedding(params)
        val kvBytes = if (layers > 0) 2L * layers * ctx * emb * 2L else ctx * 512L * 1024L
        val runtimeOverhead = max(384L shl 20, (model.fileSizeBytes * 0.08).toLong())
        val min = model.fileSizeBytes + kvBytes + runtimeOverhead
        val max = (model.fileSizeBytes * 1.15).toLong() + (kvBytes * 1.25).toLong() + runtimeOverhead
        val ratioToAvailable = max.toDouble() / mi.availMem.coerceAtLeast(1L)
        val rating = when {
            max < mi.availMem * .55 -> HardwareRating.EXCELLENT
            max < mi.availMem * .80 -> HardwareRating.SHOULD_RUN
            max < mi.availMem * 1.05 -> HardwareRating.HEAVY
            max < mi.availMem * 1.35 -> HardwareRating.VERY_HEAVY
            else -> HardwareRating.LIKELY_TOO_LARGE
        }
        val explanation = when (rating) {
            HardwareRating.EXCELLENT -> "The current configuration has comfortable estimated memory headroom."
            HardwareRating.SHOULD_RUN -> "The configuration should fit under current memory conditions, but Android memory pressure can change."
            HardwareRating.HEAVY -> "This configuration is close to currently available memory. Closing other apps or lowering context may help."
            HardwareRating.VERY_HEAVY -> "This configuration may exceed available memory during loading or generation."
            HardwareRating.LIKELY_TOO_LARGE -> "The estimate is substantially above currently available memory. Android may terminate the process."
        }
        return HardwareEstimate(model.fileSizeBytes, min, max, mi.totalMem, mi.availMem, kvBytes, rating, explanation)
    }

    fun availableStorageBytes(context: Context): Long = StatFs(context.filesDir.absolutePath).availableBytes

    private fun guessLayers(params: Long): Long = when {
        params <= 0 -> 0; params < 1_000_000_000L -> 24; params < 4_000_000_000L -> 32
        params < 9_000_000_000L -> 32; params < 16_000_000_000L -> 40; else -> 48
    }
    private fun guessEmbedding(params: Long): Long = when {
        params <= 0 -> 0; params < 1_000_000_000L -> 1024; params < 4_000_000_000L -> 2560
        params < 9_000_000_000L -> 4096; params < 16_000_000_000L -> 5120; else -> 6144
    }
}
