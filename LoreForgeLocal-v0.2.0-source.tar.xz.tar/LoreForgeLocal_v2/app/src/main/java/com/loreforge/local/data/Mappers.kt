package com.loreforge.local.data

import com.loreforge.local.model.ModelDescriptor
import com.loreforge.local.model.StorageMode

fun ModelEntity.toDescriptor() = ModelDescriptor(
    id, displayName, originalFilename, uri, localPath, fileSizeBytes, architecture,
    parameterCount, quantization, ggufVersion, tokenizer, contextCapacity,
    embeddedChatTemplate, ropeInfo, tensorCount, StorageMode.valueOf(storageMode), importedAt,
    lastUsedAt, active
)

fun ModelDescriptor.toEntity() = ModelEntity(
    id, displayName, originalFilename, uri, localPath, fileSizeBytes, architecture,
    parameterCount, quantization, ggufVersion, tokenizer, contextCapacity,
    embeddedChatTemplate, ropeInfo, tensorCount, storageMode.name, importedAt, lastUsedAt, active
)
