package com.loreforge.local.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [StoryEntity::class, BibleEntryEntity::class, MemoryEntity::class, BranchEntity::class, ModelEntity::class, SettingEntity::class, ModelProfileEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AppDao
}
