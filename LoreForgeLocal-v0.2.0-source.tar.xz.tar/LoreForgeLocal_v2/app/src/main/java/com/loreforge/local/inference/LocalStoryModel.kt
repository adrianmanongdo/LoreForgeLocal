package com.loreforge.local.inference

import com.loreforge.local.model.*
import kotlinx.coroutines.flow.Flow

interface LocalStoryModel {
    suspend fun load(model: ModelDescriptor, config: ModelLoadConfig): Result<Unit>
    suspend fun unload()
    fun generate(request: GenerationRequest): Flow<GenerationEvent>
    suspend fun stop()
    suspend fun tokenize(text: String): IntArray
    fun getContextCapacity(): Int?
    fun isLoaded(): Boolean
    fun getCapabilities(): ModelCapabilities
}
