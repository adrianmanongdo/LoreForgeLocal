package com.loreforge.local.story

import android.content.Context
import android.net.Uri
import com.loreforge.local.data.*
import com.loreforge.local.inference.HardwareEstimator
import com.loreforge.local.inference.LlamaCppModel
import com.loreforge.local.inference.ModelImportService
import com.loreforge.local.inference.ModelInspection
import com.loreforge.local.model.*
import com.loreforge.local.prompt.PromptFormatter
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class StoryRepository(
    private val context: Context,
    private val dao: AppDao,
    private val runtime: LlamaCppModel
) {
    private val importer = ModelImportService(context)
    private val contextEngine = ContextAssemblyEngine()
    private val formatter = PromptFormatter()

    val stories: Flow<List<StoryEntity>> = dao.observeStories()
    val models: Flow<List<ModelDescriptor>> = dao.observeModels().map { list -> list.map(ModelEntity::toDescriptor) }

    suspend fun ensureInitialStory(): Long {
        // Create one starter project without requiring an account or a model.
        val known = dao.setting("initial_story_id")?.value?.toLongOrNull()?.let { dao.story(it) }
        if (known != null) return known.id
        val id = dao.insertStory(StoryEntity(title = "Untitled Story"))
        dao.putSetting(SettingEntity("initial_story_id", id.toString()))
        return id
    }

    suspend fun story(id: Long) = dao.story(id)
    fun bible(id: Long) = dao.observeBible(id)
    fun branches(id: Long) = dao.observeBranches(id)
    fun profiles(modelId: Long) = dao.observeProfiles(modelId)

    suspend fun createStory(title: String): Long = dao.insertStory(StoryEntity(title = title.ifBlank { "Untitled Story" }))
    suspend fun saveStory(story: StoryEntity) = dao.updateStory(story.copy(updatedAt = System.currentTimeMillis()))
    suspend fun deleteStory(story: StoryEntity) = dao.deleteStory(story)

    suspend fun addBible(storyId: Long, category: String, name: String, content: String) =
        dao.insertBible(BibleEntryEntity(storyId = storyId, category = category, name = name, content = content))
    suspend fun deleteBible(entry: BibleEntryEntity) = dao.deleteBible(entry)

    suspend fun createBranch(story: StoryEntity, name: String): Long = dao.insertBranch(
        BranchEntity(storyId = story.id, name = name.ifBlank { "Branch" }, body = story.body, parentBranchId = story.activeBranchId)
    )
    suspend fun switchToBranch(story: StoryEntity, branch: BranchEntity) =
        saveStory(story.copy(body = branch.body, activeBranchId = branch.id))

    suspend fun globalSystemPrompt(): String = dao.setting("global_system_prompt")?.value ?: DEFAULT_SYSTEM_PROMPT
    suspend fun saveGlobalSystemPrompt(text: String) = dao.putSetting(SettingEntity("global_system_prompt", text))
    suspend fun resetGlobalSystemPrompt() = dao.putSetting(SettingEntity("global_system_prompt", DEFAULT_SYSTEM_PROMPT))

    suspend fun promptTemplate(): PromptTemplateKind = runCatching {
        PromptTemplateKind.valueOf(dao.setting("prompt_template")?.value ?: PromptTemplateKind.AUTO.name)
    }.getOrDefault(PromptTemplateKind.AUTO)
    suspend fun savePromptTemplate(kind: PromptTemplateKind) = dao.putSetting(SettingEntity("prompt_template", kind.name))
    suspend fun customTemplate(): String = dao.setting("custom_template")?.value ?: DEFAULT_CUSTOM_TEMPLATE
    suspend fun saveCustomTemplate(value: String) { formatter.validateCustom(value).getOrThrow(); dao.putSetting(SettingEntity("custom_template", value)) }

    suspend fun inspectModel(uri: Uri): Result<ModelInspection> = importer.inspect(uri)
    suspend fun copyModel(model: ModelDescriptor, onProgress: (Float) -> Unit = {}): Result<ModelDescriptor> = importer.copyIntoAppStorage(model, onProgress)
    suspend fun addModel(model: ModelDescriptor): Long = dao.insertModel(model.toEntity())

    suspend fun replaceModel(id: Long, replacement: ModelDescriptor) {
        val old = dao.model(id) ?: error("Model to replace was not found.")
        if (old.active) runtime.unload()
        importer.deleteManagedCopy(old.toDescriptor())
        dao.updateModel(replacement.copy(id = id, active = old.active, lastUsedAt = old.lastUsedAt).toEntity())
    }

    suspend fun renameModel(id: Long, name: String) {
        val m = dao.model(id) ?: return
        dao.updateModel(m.copy(displayName = name.ifBlank { m.displayName }))
    }

    suspend fun removeModel(id: Long) {
        val m = dao.model(id) ?: return
        if (m.active) runtime.unload()
        importer.deleteManagedCopy(m.toDescriptor())
        dao.deleteModel(m)
    }

    suspend fun activateModel(id: Long, config: ModelLoadConfig): Result<Unit> {
        val m = dao.model(id) ?: return Result.failure(IllegalArgumentException("Model not found."))
        dao.clearActiveModels()
        dao.activateModel(id)
        return runtime.load(m.copy(active = true).toDescriptor(), normalize(config))
    }

    suspend fun saveProfile(modelId: Long, name: String, config: ModelLoadConfig, systemPromptOverride: String?): Long =
        dao.insertProfile(ModelProfileEntity(
            modelId = modelId, name = name.ifBlank { "Profile" }, temperature = config.temperature, topP = config.topP,
            topK = config.topK, repeatPenalty = config.repeatPenalty, maxTokens = config.maxGenerationTokens,
            cpuThreads = config.cpuThreads, contextLength = config.contextLength, batchSize = config.batchSize,
            useMmap = config.useMmap, useMlock = config.useMlock, seed = config.seed, systemPromptOverride = systemPromptOverride
        ))

    suspend fun activateProfile(profile: ModelProfileEntity): ModelLoadConfig {
        dao.clearActiveProfiles(profile.modelId)
        dao.activateProfile(profile.id)
        return ModelLoadConfig(
            temperature = profile.temperature, topP = profile.topP, topK = profile.topK, repeatPenalty = profile.repeatPenalty,
            maxGenerationTokens = profile.maxTokens, cpuThreads = profile.cpuThreads, contextLength = profile.contextLength,
            batchSize = profile.batchSize, useMmap = profile.useMmap, useMlock = profile.useMlock, seed = profile.seed
        )
    }
    suspend fun deleteProfile(profile: ModelProfileEntity) = dao.deleteProfile(profile)

    suspend fun unloadModel() = runtime.unload()
    fun isModelLoaded() = runtime.isLoaded()
    fun capabilities() = runtime.getCapabilities()

    suspend fun activeDescriptor(): ModelDescriptor? = dao.activeModel()?.toDescriptor()

    suspend fun ensureActiveLoaded(config: ModelLoadConfig): Result<ModelDescriptor> {
        val active = dao.activeModel()?.toDescriptor()
            ?: return Result.failure(IllegalStateException("No local language model is currently selected.\n\nImport a compatible GGUF model from Model Manager to begin generating stories."))
        if (!runtime.isLoaded()) {
            runtime.load(active, normalize(config)).getOrElse { return Result.failure(it) }
        }
        return Result.success(active)
    }

    suspend fun hardwareEstimate(model: ModelDescriptor, config: ModelLoadConfig) = HardwareEstimator.estimate(context, model, config)
    fun availableStorageBytes() = HardwareEstimator.availableStorageBytes(context)

    suspend fun buildGenerationRequest(
        storyId: Long,
        instruction: String,
        config: ModelLoadConfig,
        template: PromptTemplateKind
    ): Result<GenerationRequest> = runCatching {
        val story = dao.story(storyId) ?: error("Story not found.")
        val bible = dao.bible(storyId)
        val memories = dao.memories(storyId)
        val activeEntity = dao.activeModel()
        val profile = activeEntity?.let { dao.activeProfile(it.id) }
        val system = story.systemPromptOverride ?: profile?.systemPromptOverride ?: globalSystemPrompt()
        val active = activeEntity?.toDescriptor()
        val ctx = contextEngine.assemble(story, bible, memories, system, instruction, config.contextLength)
        val prompt = formatter.format(
            ctx, template, active?.embeddedChatTemplate, customTemplate(),
            modelName = active?.originalFilename, architecture = active?.architecture
        )
        GenerationRequest(prompt, normalize(config))
    }

    fun generate(request: GenerationRequest): Flow<GenerationEvent> = runtime.generate(request)
    suspend fun stop() = runtime.stop()

    suspend fun remember(storyId: Long, text: String, importance: Int = 1) {
        if (text.isBlank()) return
        dao.insertMemory(MemoryEntity(storyId = storyId, text = text.take(4000), importance = importance.coerceIn(1, 5)))
        dao.trimMemories(storyId, 250)
    }

    suspend fun searchStory(storyId: Long, query: String): List<IntRange> {
        val body = dao.story(storyId)?.body ?: return emptyList()
        if (query.isBlank()) return emptyList()
        return Regex(Regex.escape(query), RegexOption.IGNORE_CASE).findAll(body).map { it.range }.toList()
    }

    private fun normalize(c: ModelLoadConfig): ModelLoadConfig = when (c.performancePreset) {
        PerformancePreset.BATTERY_SAVER -> c.copy(cpuThreads = (Runtime.getRuntime().availableProcessors() / 2).coerceAtLeast(1), batchSize = minOf(c.batchSize, 128), gpuLayers = 0)
        PerformancePreset.MAXIMUM_SPEED -> c.copy(cpuThreads = Runtime.getRuntime().availableProcessors().coerceAtLeast(1), gpuLayers = 0)
        else -> c.copy(gpuLayers = 0)
    }
}
