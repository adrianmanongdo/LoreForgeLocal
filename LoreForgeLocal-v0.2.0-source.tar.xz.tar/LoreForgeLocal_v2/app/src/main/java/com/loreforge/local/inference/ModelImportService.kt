package com.loreforge.local.inference

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.system.Os
import android.system.OsConstants
import com.loreforge.local.model.ModelDescriptor
import com.loreforge.local.model.StorageMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/** Result of selecting a GGUF through Android's Storage Access Framework. */
data class ModelInspection(
    val model: ModelDescriptor,
    val directAccessLikelyReliable: Boolean,
    val directAccessNote: String,
    val metadataWarning: String? = null
)

class ModelImportService(private val context: Context) {
    private val resolver: ContentResolver get() = context.contentResolver

    /**
     * Inspect a selected model without assuming the SAF provider behaves like a normal filesystem.
     *
     * Import is intentionally NOT made dependent on optional metadata parsing. We validate the GGUF
     * magic, then parse metadata through a large buffered sequential stream. If optional metadata is
     * unusual, the model can still be imported and llama.cpp gets the final say when loading.
     */
    suspend fun inspect(uri: Uri): Result<ModelInspection> = withContext(Dispatchers.IO) {
        runCatching {
            persistReadPermission(uri)
            val (name, size) = queryNameAndSize(uri)
            require(name.lowercase().endsWith(".gguf")) { "Select a .gguf model file." }
            require(!isSplitGguf(name)) {
                "This is one shard of a split GGUF model ($name). LoreForge currently requires a single-file GGUF. Download the non-split Q4_K_M file instead."
            }

            // Cheap validation first. This prevents a metadata-parser quirk from being confused with
            // a file-picker failure while still rejecting obviously wrong files.
            validateGgufMagic(uri)

            val metadataResult = runCatching {
                resolver.openInputStream(uri)?.use { raw ->
                    GgufMetadataReader.read(BufferedInputStream(raw, 1024 * 1024))
                } ?: error("The document provider could not open the selected model for inspection.")
            }
            val metadata = metadataResult.getOrNull()
            val metadataWarning = metadataResult.exceptionOrNull()?.let {
                "GGUF metadata could only be partially inspected (${it.message ?: it.javaClass.simpleName}). The model can still be imported and validated by llama.cpp when loaded."
            }

            val (directOk, directNote) = probeDirectNativeAccess(uri, size)
            val descriptor = ModelDescriptor(
                displayName = metadata?.name?.takeIf { it.isNotBlank() } ?: name.removeSuffix(".gguf"),
                originalFilename = name,
                uri = uri.toString(),
                localPath = null,
                fileSizeBytes = size,
                architecture = metadata?.architecture ?: inferArchitectureFromFilename(name),
                parameterCount = metadata?.parameterCount ?: inferParamsFromFilename(name),
                quantization = metadata?.quantization ?: inferQuantFromFilename(name),
                ggufVersion = metadata?.version,
                tokenizer = metadata?.tokenizer,
                contextCapacity = metadata?.contextLength,
                embeddedChatTemplate = metadata?.chatTemplate,
                ropeInfo = metadata?.ropeInfo,
                tensorCount = metadata?.tensorCount,
                storageMode = StorageMode.ORIGINAL_URI,
                importedAt = System.currentTimeMillis(),
                lastUsedAt = null,
                active = false
            )
            ModelInspection(descriptor, directOk, directNote, metadataWarning)
        }
    }

    suspend fun copyIntoAppStorage(model: ModelDescriptor, onProgress: (Float) -> Unit = {}): Result<ModelDescriptor> = withContext(Dispatchers.IO) {
        runCatching {
            val uri = model.uri?.let(Uri::parse) ?: error("Original document URI is unavailable.")
            val dir = File(context.filesDir, "models").apply { mkdirs() }
            val available = dir.usableSpace
            if (model.fileSizeBytes > 0) {
                val safetyMargin = 256L * 1024 * 1024
                require(available >= model.fileSizeBytes + safetyMargin) {
                    "Not enough app storage to copy this model. Required: about ${formatGiB(model.fileSizeBytes + safetyMargin)} GiB including safety margin; available: ${formatGiB(available)} GiB."
                }
            }
            val target = File(dir, "${UUID.randomUUID()}-${sanitize(model.originalFilename)}")
            try {
                resolver.openInputStream(uri)?.use { input ->
                    BufferedInputStream(input, 1024 * 1024).use { buffered ->
                        FileOutputStream(target).use { output ->
                            val buffer = ByteArray(4 * 1024 * 1024)
                            var copied = 0L
                            while (true) {
                                val n = buffered.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                copied += n
                                if (model.fileSizeBytes > 0) {
                                    onProgress((copied.toDouble() / model.fileSizeBytes).toFloat().coerceIn(0f, 1f))
                                }
                            }
                            output.fd.sync()
                        }
                    }
                } ?: error("The document provider could not open the model for copying.")
                require(target.length() == model.fileSizeBytes || model.fileSizeBytes <= 0) {
                    "Copied model size does not match the source. The incomplete copy was removed."
                }
                model.copy(localPath = target.absolutePath, storageMode = StorageMode.APP_MANAGED_COPY)
            } catch (t: Throwable) {
                runCatching { target.delete() }
                throw t
            }
        }
    }

    suspend fun deleteManagedCopy(model: ModelDescriptor) = withContext(Dispatchers.IO) {
        model.localPath?.let { runCatching { File(it).delete() } }
    }

    private fun persistReadPermission(uri: Uri) {
        try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Some providers do not expose persistable grants. The direct-access probe below will
            // decide whether original-location loading should be offered.
        } catch (_: UnsupportedOperationException) {
            // Same treatment: copying remains available.
        }
    }

    private fun validateGgufMagic(uri: Uri) {
        val magic = ByteArray(4)
        resolver.openInputStream(uri)?.use { input ->
            var offset = 0
            while (offset < magic.size) {
                val n = input.read(magic, offset, magic.size - offset)
                if (n < 0) error("The selected file is too small to be a GGUF model.")
                offset += n
            }
        } ?: error("Could not open the selected model.")
        require(String(magic, Charsets.US_ASCII) == "GGUF") {
            "The selected file is not a valid GGUF model (GGUF header not found)."
        }
    }

    /**
     * llama.cpp receives original-location models as /proc/self/fd/<fd>. Test the properties that
     * path needs before showing USE ORIGINAL LOCATION: a reopenable descriptor, seek support, and a
     * readable proc-fd path. This is a capability probe, not a guarantee that every mmap operation
     * on every OEM provider will succeed.
     */
    private fun probeDirectNativeAccess(uri: Uri, expectedSize: Long): Pair<Boolean, String> {
        return try {
            resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                val statSize = pfd.statSize
                if (expectedSize > 0 && statSize > 0 && statSize != expectedSize) {
                    return false to "The document provider reports an inconsistent file size, so native direct access is unsafe. Use COPY MODEL."
                }
                Os.lseek(pfd.fileDescriptor, 0L, OsConstants.SEEK_SET)
                if (statSize > 1) Os.lseek(pfd.fileDescriptor, statSize - 1, OsConstants.SEEK_SET)
                Os.lseek(pfd.fileDescriptor, 0L, OsConstants.SEEK_SET)
                val procPath = File("/proc/self/fd/${pfd.fd}")
                if (!procPath.canRead()) {
                    false to "Android did not expose this provider's descriptor as a readable native file path. Use COPY MODEL."
                } else {
                    true to "This provider exposes a seekable native file descriptor. USE ORIGINAL LOCATION should work; if llama.cpp later rejects mmap on this provider, switch to an app-managed copy."
                }
            } ?: (false to "The document provider could not reopen the selected model. Use COPY MODEL.")
        } catch (t: Throwable) {
            false to "This storage provider does not expose a reliably seekable native descriptor (${t.message ?: t.javaClass.simpleName}). Use COPY MODEL."
        }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String, Long> {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val name = if (nameIdx >= 0) c.getString(nameIdx) else (uri.lastPathSegment ?: "model.gguf")
                val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
                val size = if (sizeIdx >= 0 && !c.isNull(sizeIdx)) c.getLong(sizeIdx)
                else resolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
                return name to size
            }
        }
        return (uri.lastPathSegment ?: "model.gguf") to (resolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L)
    }

    private fun isSplitGguf(name: String): Boolean = Regex("(?i)-\\d{5}-of-\\d{5}\\.gguf$").containsMatchIn(name)
    private fun sanitize(name: String) = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun inferQuantFromFilename(name: String): String? = Regex("(?i)(Q[2-8](?:_[A-Z0-9]+)+|IQ[1-4]_[A-Z0-9_]+|F16|BF16|F32)")
        .find(name)?.value?.uppercase()

    private fun inferParamsFromFilename(name: String): Long? {
        val m = Regex("(?i)(\\d+(?:\\.\\d+)?)B").find(name) ?: return null
        return (m.groupValues[1].toDoubleOrNull()?.times(1_000_000_000.0))?.toLong()
    }

    private fun inferArchitectureFromFilename(name: String): String? = when {
        name.contains("qwen", ignoreCase = true) -> "qwen2"
        name.contains("llama", ignoreCase = true) -> "llama"
        name.contains("mistral", ignoreCase = true) -> "mistral"
        name.contains("gemma", ignoreCase = true) -> "gemma"
        else -> null
    }

    private fun formatGiB(bytes: Long): String = "%.2f".format(bytes.toDouble() / (1024.0 * 1024.0 * 1024.0))
}
