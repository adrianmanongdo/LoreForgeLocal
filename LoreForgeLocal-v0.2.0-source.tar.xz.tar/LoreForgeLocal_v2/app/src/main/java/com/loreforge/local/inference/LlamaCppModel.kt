package com.loreforge.local.inference

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.loreforge.local.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.codeshipping.llamakotlin.LlamaModel
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real local llama.cpp-backed implementation. The dependency is an Android AAR containing
 * JNI/native llama.cpp code. No network client exists in this class.
 */
class LlamaCppModel(private val appContext: Context) : LocalStoryModel {
    @Volatile private var native: LlamaModel? = null
    @Volatile private var descriptor: ModelDescriptor? = null
    @Volatile private var loadedConfig: ModelLoadConfig? = null
    private var sourceFd: ParcelFileDescriptor? = null
    private val stopping = AtomicBoolean(false)

    override suspend fun load(model: ModelDescriptor, config: ModelLoadConfig): Result<Unit> = withContext(Dispatchers.Default) {
        runCatching {
            unload()
            val path = when {
                model.localPath != null -> {
                    require(File(model.localPath).canRead()) { "The app-managed GGUF file is not readable." }
                    model.localPath
                }
                model.uri != null -> {
                    val pfd = appContext.contentResolver.openFileDescriptor(Uri.parse(model.uri), "r")
                        ?: error("The selected document provider could not reopen this model.")
                    sourceFd = pfd
                    "/proc/self/fd/${pfd.fd}"
                }
                else -> error("Model has neither a document URI nor a local path.")
            }

            val instance = LlamaModel.load(path) {
                contextSize = config.contextLength
                batchSize = config.batchSize
                threads = config.cpuThreads.coerceAtLeast(1)
                threadsBatch = config.cpuThreads.coerceAtLeast(1)
                temperature = config.temperature
                topP = config.topP
                topK = config.topK
                repeatPenalty = config.repeatPenalty
                maxTokens = config.maxGenerationTokens
                seed = config.seed
                useMmap = config.useMmap
                useMlock = config.useMlock
                // CPU/NEON is the verified universal backend in this packaged runtime.
                // Do not advertise unsupported GPU acceleration.
                gpuLayers = 0
            }
            native = instance
            descriptor = model
            loadedConfig = config
            stopping.set(false)
        }.onFailure {
            sourceFd?.close()
            sourceFd = null
            native = null
            descriptor = null
            loadedConfig = null
        }
    }

    override suspend fun unload() = withContext(Dispatchers.Default) {
        runCatching { native?.cancelGeneration() }
        runCatching { native?.close() }
        native = null
        descriptor = null
        loadedConfig = null
        runCatching { sourceFd?.close() }
        sourceFd = null
        stopping.set(false)
    }

    override fun generate(request: GenerationRequest): Flow<GenerationEvent> = flow {
        val engine = native ?: run {
            emit(GenerationEvent.Error("No local model is loaded."))
            return@flow
        }
        stopping.set(false)
        emit(GenerationEvent.State(GenerationState.Generating))
        try {
            engine.generateStream(request.prompt).collect { piece ->
                currentCoroutineContext().ensureActive()
                emit(GenerationEvent.Token(piece))
            }
            if (stopping.get()) emit(GenerationEvent.State(GenerationState.Cancelled))
            else {
                emit(GenerationEvent.State(GenerationState.Completed))
                emit(GenerationEvent.Done)
            }
        } catch (t: Throwable) {
            if (stopping.get()) emit(GenerationEvent.State(GenerationState.Cancelled))
            else emit(GenerationEvent.Error(t.message ?: "Native generation failed.", t))
        } finally {
            stopping.set(false)
        }
    }.flowOn(Dispatchers.Default)

    override suspend fun stop() = withContext(Dispatchers.Default) {
        stopping.set(true)
        native?.cancelGeneration()
    }

    override suspend fun tokenize(text: String): IntArray {
        // This AAR does not expose model tokenization in its documented Kotlin API.
        // The capability is explicitly reported as unsupported so callers never treat a heuristic as true tokens.
        throw UnsupportedOperationException("This llama.cpp binding does not expose tokenize() to Kotlin.")
    }

    override fun getContextCapacity(): Int? = descriptor?.contextCapacity
    override fun isLoaded(): Boolean = native?.isLoaded == true
    override fun getCapabilities() = ModelCapabilities(
        cpu = true,
        neon = true,
        gpuOffload = false,
        vulkan = false,
        flashAttention = false,
        tokenization = false,
        embeddedChatTemplateApplication = false
    )
}
