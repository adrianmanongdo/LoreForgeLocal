package com.loreforge.local

import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.loreforge.local.data.BibleEntryEntity
import com.loreforge.local.data.BranchEntity
import com.loreforge.local.data.ModelProfileEntity
import com.loreforge.local.model.*
import com.loreforge.local.ui.LoreForgeViewModel
import com.loreforge.local.ui.UiState
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    val vm: LoreForgeViewModel = viewModel()
                    LoreForgeRoot(vm)
                }
            }
        }
    }
}

private enum class Tab(val label: String) { STORY("Story"), BIBLE("Story Bible"), MODELS("Models"), SETTINGS("Settings") }

@Composable
private fun LoreForgeRoot(vm: LoreForgeViewModel) {
    val state by vm.state.collectAsState()
    var tab by remember { mutableStateOf(Tab.STORY) }
    val context = LocalContext.current
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/markdown")) { uri ->
        if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(vm.exportText()) } }
    }
    var replaceModelId by remember { mutableStateOf<Long?>(null) }
    val importModelLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val target = replaceModelId
            if (target == null) vm.onModelPicked(uri) else vm.onReplaceModelPicked(target, uri)
        }
        replaceModelId = null
    }
    val importStoryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Could not read story document")
                var name = uri.lastPathSegment ?: "Imported Story"
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0)
                }
                vm.importStoryText(name.substringBeforeLast('.'), text)
            }
        }
    }

    Scaffold(
        topBar = {
            Surface(shadowElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text("LoreForge Local", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Offline interactive fiction • local GGUF inference", style = MaterialTheme.typography.labelMedium)
                }
            }
        },
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Text(item.label.take(1), fontWeight = FontWeight.Bold) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (tab) {
                Tab.STORY -> StoryScreen(
                    state, vm,
                    onExport = { exportLauncher.launch("${state.currentStory?.title ?: "story"}.md") },
                    onImport = { importStoryLauncher.launch(arrayOf("text/*", "application/json", "application/octet-stream")) }
                )
                Tab.BIBLE -> BibleScreen(state, vm)
                Tab.MODELS -> ModelsScreen(
                    state, vm,
                    onImport = { replaceModelId = null; importModelLauncher.launch(arrayOf("*/*")) },
                    onReplace = { id -> replaceModelId = id; importModelLauncher.launch(arrayOf("*/*")) }
                )
                Tab.SETTINGS -> SettingsScreen(state, vm)
            }
            MessageDialogs(state, vm)
            ModelImportProgressDialog(state)
            ImportChoiceDialog(state, vm)
            HardwareDialog(state, vm)
        }
    }
}

@Composable
private fun StoryScreen(state: UiState, vm: LoreForgeViewModel, onExport: () -> Unit, onImport: () -> Unit) {
    val story = state.currentStory
    var branchDialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = story?.title.orEmpty(), onValueChange = vm::renameStory,
                label = { Text("Project") }, modifier = Modifier.weight(1f), singleLine = true
            )
            Button(onClick = vm::newStory) { Text("NEW") }
            TextButton(onClick = onImport) { Text("IMPORT") }
            TextButton(onClick = vm::deleteCurrentStory) { Text("DELETE") }
        }
        val active = state.models.firstOrNull { it.active }
        AssistChip(
            onClick = {},
            label = { Text(active?.let { "Local model: ${it.displayName}" } ?: "No local model selected") }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = vm::undo, enabled = state.generationState == GenerationState.Idle) { Text("UNDO") }
            TextButton(onClick = vm::redo, enabled = state.generationState == GenerationState.Idle) { Text("REDO") }
            TextButton(onClick = { branchDialog = true }) { Text("BRANCH") }
            TextButton(onClick = onExport) { Text("EXPORT") }
            if (state.lastInstruction != null) {
                TextButton(onClick = vm::regenerate, enabled = state.generationState == GenerationState.Idle) { Text("REGENERATE") }
                TextButton(onClick = vm::alternativeGeneration, enabled = state.generationState == GenerationState.Idle) { Text("ALTERNATIVE") }
            }
            Spacer(Modifier.weight(1f))
            Text(state.generationState.name, style = MaterialTheme.typography.labelMedium)
        }
        OutlinedTextField(
            value = story?.body.orEmpty(),
            onValueChange = vm::editBody,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            label = { Text("Story") },
            readOnly = state.generationState in setOf(GenerationState.PreparingContext, GenerationState.Tokenizing, GenerationState.Generating, GenerationState.Stopping),
            placeholder = { Text("Write a beginning, or give the model a direction below.") }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = vm::search,
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Search story") },
                supportingText = { if (state.searchQuery.isNotBlank()) Text("${state.searchHits} match(es)") }
            )
        }
        OutlinedTextField(
            value = state.direction,
            onValueChange = vm::setDirection,
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            maxLines = 4,
            label = { Text("Your next direction") },
            placeholder = { Text("Example: The detective realizes the letter was written yesterday. Continue for two sentences.") }
        )
        val running = state.generationState in setOf(GenerationState.PreparingContext, GenerationState.Tokenizing, GenerationState.Generating, GenerationState.Stopping)
        if (running) {
            Button(onClick = vm::stop, enabled = state.generationState != GenerationState.Stopping, modifier = Modifier.fillMaxWidth()) { Text("STOP") }
        } else {
            Button(onClick = vm::generate, modifier = Modifier.fillMaxWidth()) { Text("GENERATE LOCALLY") }
        }
        if (active == null) {
            Text(
                "No local language model is currently selected. Import a compatible GGUF model from Model Manager to begin generating stories.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        if (state.branches.isNotEmpty()) {
            Text("Branches", fontWeight = FontWeight.SemiBold)
            Row(Modifier.fillMaxWidth().horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                state.branches.take(8).forEach { b -> AssistChip(onClick = { vm.switchBranch(b) }, label = { Text(b.name) }) }
            }
        }
    }
    if (branchDialog) {
        TextInputDialog("Create branch", "Branch name", onDismiss = { branchDialog = false }) { vm.createBranch(it); branchDialog = false }
    }
}

@Composable
private fun BibleScreen(state: UiState, vm: LoreForgeViewModel) {
    var addDialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Story Bible", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Persistent canon stored only on this device.", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = { addDialog = true }) { Text("ADD") }
        }
        Spacer(Modifier.height(8.dp))
        if (state.bible.isEmpty()) Text("No canon entries yet. Add characters, locations, objects, relationships, or timeline events.")
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            state.bible.forEach { entry -> BibleCard(entry, vm) }
        }
    }
    if (addDialog) {
        BibleAddDialog(onDismiss = { addDialog = false }) { cat, name, content ->
            vm.addBible(cat, name, content); addDialog = false
        }
    }
}

@Composable
private fun BibleCard(entry: BibleEntryEntity, vm: LoreForgeViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("${entry.category.uppercase()} • ${entry.name}", fontWeight = FontWeight.Bold)
            Text(entry.content)
            TextButton(onClick = { vm.deleteBible(entry) }) { Text("DELETE") }
        }
    }
}

@Composable
private fun ModelsScreen(state: UiState, vm: LoreForgeViewModel, onImport: () -> Unit, onReplace: (Long) -> Unit) {
    var profileDialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Local Model Manager", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Manual GGUF import. No automatic model download.", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onImport) { Text("IMPORT MODEL") }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Runtime capabilities", fontWeight = FontWeight.Bold)
                val c = vm.getApplication<LoreForgeApp>().repository.capabilities()
                Text("CPU: available • ARM/NEON: available")
                Text("Vulkan / GPU offload / Flash Attention: not exposed by this packaged runtime, so no ineffective controls are shown.", style = MaterialTheme.typography.bodySmall)
            }
        }
        if (state.models.isEmpty()) Text("No GGUF models imported yet.")
        state.models.forEach { model -> ModelCard(model, state, vm, onReplace) }

        val active = state.models.firstOrNull { it.active }
        if (active != null) {
            HorizontalDivider()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Profiles for ${active.displayName}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(onClick = { profileDialog = true }) { Text("SAVE PROFILE") }
            }
            if (state.profiles.isEmpty()) Text("No model profiles saved.")
            state.profiles.forEach { p -> ProfileCard(p, vm) }
        }
    }
    if (profileDialog) {
        ProfileDialog(onDismiss = { profileDialog = false }) { name, system ->
            vm.saveCurrentProfile(name, system.ifBlank { null }); profileDialog = false
        }
    }
}

@Composable
private fun ModelCard(model: ModelDescriptor, state: UiState, vm: LoreForgeViewModel, onReplace: (Long)->Unit) {
    var rename by remember(model.id) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(model.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (model.active) SuggestionChip(onClick = {}, label = { Text("SELECTED") })
            }
            Text(model.originalFilename, style = MaterialTheme.typography.bodySmall)
            MetaLine("Architecture", model.architecture ?: "Unknown")
            MetaLine("Parameters", model.parameterCount?.let(::formatParams) ?: "Unknown")
            MetaLine("Quantization", model.quantization ?: "Unknown")
            MetaLine("File size", vm.formatBytes(model.fileSizeBytes))
            MetaLine("Maximum context", model.contextCapacity?.let { "${it} tokens" } ?: "Unknown")
            MetaLine("GGUF", model.ggufVersion?.let { "Version $it" } ?: "Unknown")
            MetaLine("Tokenizer", model.tokenizer ?: "Unknown")
            MetaLine("Chat template", if (model.embeddedChatTemplate.isNullOrBlank()) "Not detected" else "Detected in GGUF metadata")
            MetaLine("Storage", if (model.storageMode == StorageMode.APP_MANAGED_COPY) "App-managed copy" else "Original document location")
            MetaLine("Source", model.localPath ?: model.uri ?: "Unknown")
            MetaLine("Imported", formatDate(model.importedAt))
            MetaLine("Last used", model.lastUsedAt?.let(::formatDate) ?: "Never")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { vm.requestLoad(model) }) { Text(if (model.active) "RELOAD" else "LOAD") }
                if (model.active) OutlinedButton(onClick = vm::unloadModel) { Text("UNLOAD") }
                TextButton(onClick = { rename = true }) { Text("RENAME") }
                TextButton(onClick = { onReplace(model.id) }) { Text("REPLACE") }
                TextButton(onClick = { vm.removeModel(model) }) { Text("REMOVE") }
            }
        }
    }
    if (rename) TextInputDialog("Rename model", "Display name", initial = model.displayName, onDismiss = { rename = false }) { vm.renameModel(model, it); rename = false }
}

@Composable
private fun ProfileCard(p: ModelProfileEntity, vm: LoreForgeViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.Bold)
                Text("ctx ${p.contextLength} • ${p.maxTokens} max tokens • temp ${p.temperature}", style = MaterialTheme.typography.bodySmall)
                if (!p.systemPromptOverride.isNullOrBlank()) Text("Includes a profile-level system prompt override", style = MaterialTheme.typography.labelSmall)
            }
            TextButton(onClick = { vm.activateProfile(p) }) { Text(if (p.active) "ACTIVE" else "USE") }
            TextButton(onClick = { vm.deleteProfile(p) }) { Text("DELETE") }
        }
    }
}

@Composable
private fun SettingsScreen(state: UiState, vm: LoreForgeViewModel) {
    Column(Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Story Engine Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Application system prompt", fontWeight = FontWeight.Bold)
        OutlinedTextField(state.globalSystemPrompt, vm::setGlobalPrompt, modifier = Modifier.fillMaxWidth(), minLines = 8, label = { Text("Global system prompt") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = vm::saveGlobalPrompt) { Text("SAVE") }
            OutlinedButton(onClick = vm::resetGlobalPrompt) { Text("RESET TO DEFAULT") }
        }

        HorizontalDivider()
        Text("Per-story system prompt", fontWeight = FontWeight.Bold)
        val story = state.currentStory
        if (story?.systemPromptOverride == null) {
            Text("Active level: ${if (state.profiles.firstOrNull { it.active }?.systemPromptOverride.isNullOrBlank()) "Application Default" else "Profile Override"}")
            Button(onClick = { vm.setStoryPromptOverride(state.globalSystemPrompt) }) { Text("CREATE STORY OVERRIDE") }
        } else {
            Text("Active level: Story Override")
            OutlinedTextField(story.systemPromptOverride, { vm.setStoryPromptOverride(it) }, modifier = Modifier.fillMaxWidth(), minLines = 5)
            OutlinedButton(onClick = { vm.setStoryPromptOverride(null) }) { Text("USE GLOBAL / PROFILE DEFAULT") }
        }

        HorizontalDivider()
        Text("Prompt Template", fontWeight = FontWeight.Bold)
        TemplateSelector(state.template, vm::setTemplate)
        if (state.template == PromptTemplateKind.CUSTOM) {
            OutlinedTextField(state.customTemplate, vm::setCustomTemplate, modifier = Modifier.fillMaxWidth(), minLines = 10, label = { Text("Custom template") })
            Text("Variables: {{system}}, {{story_context}}, {{memory}}, {{story_bible}}, {{characters}}, {{timeline}}, {{user_instruction}}, {{assistant_prefix}}", style = MaterialTheme.typography.bodySmall)
            Button(onClick = vm::saveCustomTemplate) { Text("VALIDATE & SAVE TEMPLATE") }
        }

        HorizontalDivider()
        Text("Basic generation controls", fontWeight = FontWeight.Bold)
        PresetRow("Creativity", CreativityPreset.entries.map { it.name.replace('_',' ') }, state.config.creativityPreset.ordinal) { idx ->
            val p = CreativityPreset.entries[idx]
            val c = when (p) {
                CreativityPreset.PRECISE -> state.config.copy(creativityPreset=p, temperature=.2f, topP=.85f, topK=20)
                CreativityPreset.BALANCED -> state.config.copy(creativityPreset=p, temperature=.8f, topP=.95f, topK=40)
                CreativityPreset.CREATIVE -> state.config.copy(creativityPreset=p, temperature=1.05f, topP=.97f, topK=60)
                CreativityPreset.WILD -> state.config.copy(creativityPreset=p, temperature=1.35f, topP=.99f, topK=100)
                CreativityPreset.CUSTOM -> state.config.copy(creativityPreset=p)
            }; vm.setConfig(c)
        }
        PresetRow("Response length", listOf("1 sentence","2 sentences","Short","Medium","Long","Custom"), state.config.responseLengthPreset.ordinal) { idx ->
            val p = ResponseLengthPreset.entries[idx]
            val n = when(p){ ResponseLengthPreset.ONE_SENTENCE->64; ResponseLengthPreset.TWO_SENTENCES->110; ResponseLengthPreset.SHORT->256; ResponseLengthPreset.MEDIUM->512; ResponseLengthPreset.LONG->1024; ResponseLengthPreset.CUSTOM->state.config.maxGenerationTokens }
            vm.setConfig(state.config.copy(responseLengthPreset=p, maxGenerationTokens=n))
        }
        PresetRow("Performance", listOf("Auto","Battery Saver","Balanced","Maximum Speed","Custom"), state.config.performancePreset.ordinal) { idx -> vm.setConfig(state.config.copy(performancePreset=PerformancePreset.entries[idx])) }

        OutlinedButton(onClick = vm::toggleAdvanced) { Text(if (state.advancedSettings) "HIDE ADVANCED" else "SHOW ADVANCED") }
        if (state.advancedSettings) AdvancedSettings(state, vm)

        HorizontalDivider()
        Text("Privacy by architecture", fontWeight = FontWeight.Bold)
        Text("This release declares no Android INTERNET permission. Story text, prompts, Story Bible content, model prompts, and generated prose are stored and processed locally. No analytics, ads, remote crash reporting, accounts, or moderation API dependency is included.")
    }
}

@Composable
private fun AdvancedSettings(state: UiState, vm: LoreForgeViewModel) {
    val c = state.config
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        FloatSetting("Temperature", c.temperature, 0f..2f) { vm.setConfig(c.copy(temperature=it, creativityPreset=CreativityPreset.CUSTOM)) }
        FloatSetting("Top P", c.topP, 0f..1f) { vm.setConfig(c.copy(topP=it, creativityPreset=CreativityPreset.CUSTOM)) }
        IntSetting("Top K", c.topK, 0..200) { vm.setConfig(c.copy(topK=it, creativityPreset=CreativityPreset.CUSTOM)) }
        FloatSetting("Repeat penalty", c.repeatPenalty, .8f..1.5f) { vm.setConfig(c.copy(repeatPenalty=it)) }
        IntSetting("Maximum generation tokens", c.maxGenerationTokens, 16..2048) { vm.setConfig(c.copy(maxGenerationTokens=it, responseLengthPreset=ResponseLengthPreset.CUSTOM)) }
        IntSetting("CPU threads", c.cpuThreads, 1..Runtime.getRuntime().availableProcessors().coerceAtLeast(1)) { vm.setConfig(c.copy(cpuThreads=it, performancePreset=PerformancePreset.CUSTOM)) }
        IntSetting("Context length", c.contextLength, 512..32768, step=512) { vm.setConfig(c.copy(contextLength=it)) }
        IntSetting("Batch size", c.batchSize, 32..1024, step=32) { vm.setConfig(c.copy(batchSize=it)) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Memory mapping", Modifier.weight(1f)); Switch(c.useMmap, { vm.setConfig(c.copy(useMmap=it)) }) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Memory locking", Modifier.weight(1f)); Switch(c.useMlock, { vm.setConfig(c.copy(useMlock=it)) }) }
        Text("GPU layers, Flash Attention, Min P, Typical P, presence/frequency penalties, micro-batch size, and sampler ordering are intentionally hidden because this packaged runtime does not expose them reliably.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun TemplateSelector(selected: PromptTemplateKind, onSelect: (PromptTemplateKind)->Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        PromptTemplateKind.entries.forEach { k ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected == k, onClick = { onSelect(k) })
                Text(when(k){
                    PromptTemplateKind.AUTO -> "Auto — prefer recognized GGUF template; otherwise raw"
                    PromptTemplateKind.GGUF_DETECTED -> "GGUF detected — require a recognized embedded template"
                    else -> k.name.replace('_',' ')
                })
            }
        }
    }
}

@Composable
private fun ModelImportProgressDialog(state: UiState) {
    if (!state.inspectingModel) return
    AlertDialog(
        onDismissRequest = {},
        title = { Text("Inspecting local model") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Text("Reading the GGUF header and metadata from Android storage. Large tokenizer metadata can take a few seconds. The model is not being uploaded anywhere.")
            }
        },
        confirmButton = {}
    )
}

@Composable
private fun ImportChoiceDialog(state: UiState, vm: LoreForgeViewModel) {
    val m = state.pendingImport ?: return
    AlertDialog(
        onDismissRequest = vm::cancelPendingImport,
        title = { Text("Import GGUF model") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(m.displayName, fontWeight = FontWeight.Bold)
                Text("Model size: ${vm.formatBytes(m.fileSizeBytes)}")
                Text("Additional storage required if copied: approximately ${vm.formatBytes(m.fileSizeBytes)}")
                Text("Available app storage: ${vm.formatBytes(vm.availableStorage())}")
                state.pendingMetadataWarning?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    state.pendingDirectAccessNote ?: "Direct-access capability was not determined.",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (state.pendingDirectAccessReliable) FontWeight.Normal else FontWeight.Bold
                )
                if (!state.pendingDirectAccessReliable) {
                    Text("USE ORIGINAL LOCATION is disabled for this provider. COPY MODEL will make a private app-managed copy and is the reliable option.", style = MaterialTheme.typography.bodySmall)
                }
                if (state.copyingModel) {
                    LinearProgressIndicator(progress = { state.copyProgress }, modifier = Modifier.fillMaxWidth())
                    Text("Copying ${(state.copyProgress * 100).toInt()}% — keep LoreForge open until this finishes.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { Button(onClick = vm::copyPendingModel, enabled = !state.copyingModel) { Text("COPY MODEL") } },
        dismissButton = {
            Row {
                TextButton(onClick = vm::importOriginalLocation, enabled = !state.copyingModel && state.pendingDirectAccessReliable) { Text("USE ORIGINAL LOCATION") }
                TextButton(onClick = vm::cancelPendingImport, enabled = !state.copyingModel) { Text("CANCEL") }
            }
        }
    )
}

@Composable
private fun HardwareDialog(state: UiState, vm: LoreForgeViewModel) {
    val model = state.loadCandidate ?: return
    val e = state.hardwareEstimate ?: return
    AlertDialog(
        onDismissRequest = vm::cancelLoad,
        title = { Text("Hardware estimate: ${e.rating.name.replace('_',' ')}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(model.displayName, fontWeight = FontWeight.Bold)
                Text("Model: ${vm.formatBytes(e.modelBytes)}")
                Text("Estimated runtime: ${vm.formatBytes(e.estimatedMinBytes)}–${vm.formatBytes(e.estimatedMaxBytes)}")
                Text("Approx. KV cache: ${vm.formatBytes(e.kvCacheBytes)}")
                Text("Device RAM: ${vm.formatBytes(e.totalRamBytes)}")
                Text("Current available memory: ${vm.formatBytes(e.availableRamBytes)}")
                Text(e.explanation)
                Text("This is an estimate, not an arbitrary restriction. LOAD ANYWAY remains available.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { Button(onClick = vm::confirmLoad) { Text("LOAD ANYWAY") } },
        dismissButton = {
            Row {
                TextButton(onClick = { vm.setConfig(state.config.copy(contextLength = (state.config.contextLength / 2).coerceAtLeast(512))); vm.cancelLoad() }) { Text("LOWER CONTEXT") }
                TextButton(onClick = vm::cancelLoad) { Text("CANCEL") }
            }
        }
    )
}

@Composable
private fun MessageDialogs(state: UiState, vm: LoreForgeViewModel) {
    state.error?.let { msg ->
        AlertDialog(onDismissRequest = vm::clearMessages, title = { Text("Local engine") }, text = { SelectionContainer { Text(msg) } }, confirmButton = { TextButton(onClick=vm::clearMessages){ Text("OK") } })
    }
    if (state.error == null) state.info?.let { msg ->
        AlertDialog(onDismissRequest = vm::clearMessages, title = { Text("LoreForge Local") }, text = { Text(msg) }, confirmButton = { TextButton(onClick=vm::clearMessages){ Text("OK") } })
    }
}

@Composable
private fun BibleAddDialog(onDismiss: ()->Unit, onAdd: (String,String,String)->Unit) {
    var category by remember { mutableStateOf("Character") }
    var name by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("Add Story Bible entry")}, text={
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(category,{category=it},label={Text("Category")},singleLine=true)
            OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true)
            OutlinedTextField(content,{content=it},label={Text("Canon fact")},minLines=3)
        }
    }, confirmButton={ Button(onClick={onAdd(category,name,content)},enabled=name.isNotBlank()&&content.isNotBlank()){Text("ADD")} }, dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})
}

@Composable
private fun ProfileDialog(onDismiss: ()->Unit, onSave: (String,String)->Unit) {
    var name by remember { mutableStateOf("") }
    var system by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("Save model profile")}, text={
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(name,{name=it},label={Text("Profile name")},singleLine=true)
            OutlinedTextField(system,{system=it},label={Text("Optional profile system-prompt override")},minLines=4)
        }
    }, confirmButton={ Button(onClick={onSave(name,system)},enabled=name.isNotBlank()){Text("SAVE")} }, dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})
}

@Composable
private fun TextInputDialog(title: String, label: String, initial: String="", onDismiss: ()->Unit, onSave: (String)->Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={OutlinedTextField(value,{value=it},label={Text(label)},singleLine=true)},confirmButton={Button(onClick={onSave(value)},enabled=value.isNotBlank()){Text("SAVE")}},dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})
}

@Composable private fun MetaLine(label:String,value:String){ Row { Text("$label: ",fontWeight=FontWeight.SemiBold); Text(value) } }
private fun formatParams(p: Long): String = when { p >= 1_000_000_000L -> "%.2fB".format(p/1e9); p >= 1_000_000L -> "%.1fM".format(p/1e6); else -> p.toString() }
private fun formatDate(epoch: Long): String = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(epoch))

@Composable
private fun PresetRow(label:String, items:List<String>, selected:Int, onSelect:(Int)->Unit){
    Text(label, fontWeight=FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth().horizontalScrollCompat(), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        items.forEachIndexed { i, item -> FilterChip(selected=i==selected,onClick={onSelect(i)},label={Text(item)}) }
    }
}

@Composable
private fun FloatSetting(label:String,value:Float,range:ClosedFloatingPointRange<Float>,onChange:(Float)->Unit){
    Column { Text("$label: ${"%.2f".format(value)}"); Slider(value,onChange,valueRange=range) }
}

@Composable
private fun IntSetting(label:String,value:Int,range:IntRange,step:Int=1,onChange:(Int)->Unit){
    val steps=((range.last-range.first)/step-1).coerceAtLeast(0)
    Column { Text("$label: $value"); Slider(value.toFloat(),{v-> val x=((v-range.first)/step).toInt()*step+range.first; onChange(x.coerceIn(range))},valueRange=range.first.toFloat()..range.last.toFloat(),steps=steps.coerceAtMost(1000)) }
}

@Composable
private fun Modifier.horizontalScrollCompat(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))
