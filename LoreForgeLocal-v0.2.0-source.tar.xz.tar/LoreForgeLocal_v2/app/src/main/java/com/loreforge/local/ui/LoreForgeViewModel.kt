package com.loreforge.local.ui

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.loreforge.local.LoreForgeApp
import com.loreforge.local.data.*
import com.loreforge.local.model.*
import com.loreforge.local.story.DEFAULT_SYSTEM_PROMPT
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.DecimalFormat


data class UiState(
    val currentStory: StoryEntity? = null,
    val stories: List<StoryEntity> = emptyList(),
    val bible: List<BibleEntryEntity> = emptyList(),
    val branches: List<BranchEntity> = emptyList(),
    val models: List<ModelDescriptor> = emptyList(),
    val profiles: List<ModelProfileEntity> = emptyList(),
    val direction: String = "",
    val generationState: GenerationState = GenerationState.Idle,
    val error: String? = null,
    val info: String? = null,
    val config: ModelLoadConfig = ModelLoadConfig(),
    val template: PromptTemplateKind = PromptTemplateKind.AUTO,
    val globalSystemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val customTemplate: String = "",
    val pendingImport: ModelDescriptor? = null,
    val pendingReplaceModelId: Long? = null,
    val inspectingModel: Boolean = false,
    val pendingDirectAccessReliable: Boolean = false,
    val pendingDirectAccessNote: String? = null,
    val pendingMetadataWarning: String? = null,
    val copyingModel: Boolean = false,
    val copyProgress: Float = 0f,
    val loadCandidate: ModelDescriptor? = null,
    val hardwareEstimate: HardwareEstimate? = null,
    val advancedSettings: Boolean = false,
    val searchQuery: String = "",
    val searchHits: Int = 0,
    val lastInstruction: String? = null,
    val lastGenerationBaseBody: String? = null,
)

class LoreForgeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as LoreForgeApp
    private val repo = app.repository
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var storySaveJob: Job? = null
    private var generationJob: Job? = null
    private var bibleJob: Job? = null
    private var branchJob: Job? = null
    private var profileJob: Job? = null
    private var watchedProfileModelId: Long? = null
    private val undo = ArrayDeque<String>()
    private val redo = ArrayDeque<String>()

    init {
        viewModelScope.launch {
            combine(repo.stories, repo.models) { stories, models -> stories to models }.collect { (stories, models) ->
                _state.update { it.copy(stories = stories, models = models) }
                val activeModelId = models.firstOrNull { it.active }?.id
                if (activeModelId != watchedProfileModelId) {
                    watchedProfileModelId = activeModelId
                    profileJob?.cancel()
                    if (activeModelId == null) _state.update { it.copy(profiles = emptyList()) }
                    else profileJob = launch { repo.profiles(activeModelId).collect { p -> _state.update { s -> s.copy(profiles = p) } } }
                }
                if (_state.value.currentStory == null) {
                    val id = stories.firstOrNull()?.id ?: repo.ensureInitialStory()
                    selectStory(id)
                } else {
                    val fresh = stories.firstOrNull { it.id == _state.value.currentStory?.id }
                    if (fresh != null && _state.value.generationState == GenerationState.Idle && storySaveJob?.isActive != true) {
                        _state.update { it.copy(currentStory = fresh) }
                    }
                }
            }
        }
        viewModelScope.launch {
            _state.update { it.copy(globalSystemPrompt = repo.globalSystemPrompt(), template = repo.promptTemplate(), customTemplate = repo.customTemplate()) }
        }
    }

    fun selectStory(id: Long) {
        viewModelScope.launch {
            val story = repo.story(id) ?: return@launch
            undo.clear(); redo.clear()
            _state.update { it.copy(currentStory = story, error = null, searchHits = 0) }
            bibleJob?.cancel(); branchJob?.cancel()
            bibleJob = launch { repo.bible(id).collect { b -> _state.update { s -> s.copy(bible = b) } } }
            branchJob = launch { repo.branches(id).collect { b -> _state.update { s -> s.copy(branches = b) } } }
        }
    }

    fun newStory() = viewModelScope.launch { selectStory(repo.createStory("Untitled Story")) }

    fun deleteCurrentStory() {
        val s = _state.value.currentStory ?: return
        viewModelScope.launch {
            repo.deleteStory(s)
            _state.update { it.copy(currentStory = null, bible = emptyList(), branches = emptyList()) }
            delay(50)
            val remaining = _state.value.stories.firstOrNull { it.id != s.id }
            selectStory(remaining?.id ?: repo.createStory("Untitled Story"))
        }
    }

    fun importStoryText(title: String, text: String) = viewModelScope.launch {
        val id = repo.createStory(title.ifBlank { "Imported Story" })
        val story = repo.story(id) ?: return@launch
        repo.saveStory(story.copy(body = text))
        selectStory(id)
    }

    fun renameStory(title: String) {
        val s = _state.value.currentStory ?: return
        val updated = s.copy(title = title)
        _state.update { it.copy(currentStory = updated) }
        scheduleStorySave(updated)
    }

    fun editBody(body: String) {
        val s = _state.value.currentStory ?: return
        if (body == s.body) return
        if (_state.value.generationState == GenerationState.Idle) pushUndo(s.body)
        redo.clear()
        val updated = s.copy(body = body)
        _state.update { it.copy(currentStory = updated) }
        scheduleStorySave(updated)
    }

    fun undo() {
        val s = _state.value.currentStory ?: return
        if (undo.isEmpty() || _state.value.generationState != GenerationState.Idle) return
        redo.addLast(s.body)
        val body = undo.removeLast()
        val updated = s.copy(body = body)
        _state.update { it.copy(currentStory = updated) }
        scheduleStorySave(updated)
    }

    fun redo() {
        val s = _state.value.currentStory ?: return
        if (redo.isEmpty() || _state.value.generationState != GenerationState.Idle) return
        undo.addLast(s.body)
        val body = redo.removeLast()
        val updated = s.copy(body = body)
        _state.update { it.copy(currentStory = updated) }
        scheduleStorySave(updated)
    }

    fun setDirection(value: String) = _state.update { it.copy(direction = value) }

    fun generate() {
        if (generationJob?.isActive == true) return
        val story = _state.value.currentStory ?: return
        val instruction = _state.value.direction.trim().ifBlank { "Continue the story naturally from the current point." }
        pushUndo(story.body); redo.clear()
        generationJob = viewModelScope.launch {
            _state.update { it.copy(generationState = GenerationState.PreparingContext, error = null, info = null, lastInstruction = instruction, lastGenerationBaseBody = story.body) }
            repo.ensureActiveLoaded(_state.value.config).onFailure {
                _state.update { s -> s.copy(generationState = GenerationState.Failed, error = it.message) }
                return@launch
            }
            val req = repo.buildGenerationRequest(story.id, instruction, _state.value.config, _state.value.template).getOrElse {
                _state.update { s -> s.copy(generationState = GenerationState.Failed, error = it.message) }
                return@launch
            }
            val initialBody = _state.value.currentStory?.body.orEmpty()
            val generated = StringBuilder()
            var pending = StringBuilder()
            var lastFlush = SystemClock.elapsedRealtime()
            repo.generate(req).collect { event ->
                when (event) {
                    is GenerationEvent.State -> _state.update { it.copy(generationState = event.state) }
                    is GenerationEvent.Token -> {
                        generated.append(event.text); pending.append(event.text)
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastFlush >= 32 || pending.length >= 96) {
                            appendGenerated(pending.toString()); pending = StringBuilder(); lastFlush = now
                        }
                    }
                    is GenerationEvent.Error -> _state.update { it.copy(generationState = GenerationState.Failed, error = event.message) }
                    GenerationEvent.Done -> Unit
                }
            }
            if (pending.isNotEmpty()) appendGenerated(pending.toString())
            val finalStory = _state.value.currentStory
            if (finalStory != null) repo.saveStory(finalStory)
            if (generated.isNotBlank()) repo.remember(story.id, "Direction: $instruction\nResult: ${generated.toString().take(1800)}", 2)
            _state.update { s ->
                val terminal = if (s.generationState == GenerationState.Cancelled) GenerationState.Cancelled else if (s.generationState == GenerationState.Failed) GenerationState.Failed else GenerationState.Completed
                s.copy(generationState = terminal, direction = if (generated.isNotBlank()) "" else s.direction)
            }
            delay(250)
            if (_state.value.generationState in setOf(GenerationState.Completed, GenerationState.Cancelled)) _state.update { it.copy(generationState = GenerationState.Idle) }
        }
    }

    fun regenerate() {
        if (generationJob?.isActive == true) return
        val base = _state.value.lastGenerationBaseBody ?: return
        val instruction = _state.value.lastInstruction ?: return
        val current = _state.value.currentStory ?: return
        pushUndo(current.body)
        val restored = current.copy(body = base)
        _state.update { it.copy(currentStory = restored, direction = instruction) }
        scheduleStorySave(restored)
        generate()
    }

    fun alternativeGeneration() {
        if (generationJob?.isActive == true) return
        val base = _state.value.lastGenerationBaseBody ?: return
        val instruction = _state.value.lastInstruction ?: return
        val current = _state.value.currentStory ?: return
        viewModelScope.launch {
            repo.createBranch(current, "Saved generation ${System.currentTimeMillis()}")
            pushUndo(current.body)
            val restored = current.copy(body = base)
            repo.saveStory(restored)
            _state.update { it.copy(currentStory = restored, direction = instruction, info = "Previous generation saved as a branch. Generating an alternative…") }
            delay(100)
            _state.update { it.copy(info = null) }
            generate()
        }
    }

    fun stop() {
        if (_state.value.generationState !in setOf(GenerationState.PreparingContext, GenerationState.Tokenizing, GenerationState.Generating)) return
        _state.update { it.copy(generationState = GenerationState.Stopping) }
        viewModelScope.launch { repo.stop() }
    }

    private fun appendGenerated(text: String) {
        if (text.isEmpty()) return
        val s = _state.value.currentStory ?: return
        val separator = if (s.body.isNotBlank() && !s.body.endsWith("\n") && s.body.lastOrNull()?.isWhitespace() == false && text.firstOrNull()?.isWhitespace() == false) " " else ""
        _state.update { it.copy(currentStory = s.copy(body = s.body + separator + text)) }
    }

    fun onModelPicked(uri: Uri) = inspectPickedModel(uri, null)
    fun onReplaceModelPicked(modelId: Long, uri: Uri) = inspectPickedModel(uri, modelId)

    private fun inspectPickedModel(uri: Uri, replaceId: Long?) = viewModelScope.launch {
        _state.update {
            it.copy(
                error = null, info = null, inspectingModel = true,
                pendingImport = null, pendingReplaceModelId = replaceId,
                pendingDirectAccessReliable = false, pendingDirectAccessNote = null, pendingMetadataWarning = null
            )
        }
        repo.inspectModel(uri).onSuccess { inspection ->
            _state.update {
                it.copy(
                    inspectingModel = false,
                    pendingImport = inspection.model,
                    pendingReplaceModelId = replaceId,
                    pendingDirectAccessReliable = inspection.directAccessLikelyReliable,
                    pendingDirectAccessNote = inspection.directAccessNote,
                    pendingMetadataWarning = inspection.metadataWarning,
                    info = null
                )
            }
        }.onFailure { e ->
            _state.update { it.copy(inspectingModel = false, error = e.message ?: "Model inspection failed.", info = null) }
        }
    }

    fun cancelPendingImport() = _state.update {
        it.copy(
            pendingImport = null, pendingReplaceModelId = null, inspectingModel = false,
            pendingDirectAccessReliable = false, pendingDirectAccessNote = null, pendingMetadataWarning = null,
            copyingModel = false, copyProgress = 0f
        )
    }

    fun importOriginalLocation() = viewModelScope.launch {
        val m = _state.value.pendingImport ?: return@launch
        if (!_state.value.pendingDirectAccessReliable) {
            _state.update { it.copy(error = _state.value.pendingDirectAccessNote ?: "This provider is not reliable for native direct access. Use COPY MODEL.") }
            return@launch
        }
        val replaceId = _state.value.pendingReplaceModelId
        if (replaceId != null) repo.replaceModel(replaceId, m) else repo.addModel(m)
        _state.update {
            it.copy(
                pendingImport = null, pendingReplaceModelId = null,
                pendingDirectAccessReliable = false, pendingDirectAccessNote = null, pendingMetadataWarning = null,
                info = if (replaceId != null) "Model source replaced." else "Model added using its original document location."
            )
        }
    }

    fun copyPendingModel() = viewModelScope.launch {
        val m = _state.value.pendingImport ?: return@launch
        _state.update { it.copy(copyingModel = true, copyProgress = 0f) }
        repo.copyModel(m) { p -> _state.update { s -> s.copy(copyProgress = p) } }.onSuccess { copied ->
            val replaceId = _state.value.pendingReplaceModelId
            if (replaceId != null) repo.replaceModel(replaceId, copied) else repo.addModel(copied)
            _state.update {
                it.copy(
                    pendingImport = null, pendingReplaceModelId = null,
                    pendingDirectAccessReliable = false, pendingDirectAccessNote = null, pendingMetadataWarning = null,
                    copyingModel = false, copyProgress = 0f,
                    info = if (replaceId != null) "Model replaced with an app-managed copy." else "Model copied into app-managed storage."
                )
            }
        }.onFailure { e -> _state.update { it.copy(copyingModel = false, error = e.message) } }
    }

    fun requestLoad(model: ModelDescriptor) = viewModelScope.launch {
        val estimate = repo.hardwareEstimate(model, _state.value.config)
        _state.update { it.copy(loadCandidate = model, hardwareEstimate = estimate, error = null) }
    }

    fun cancelLoad() = _state.update { it.copy(loadCandidate = null, hardwareEstimate = null) }

    fun confirmLoad() = viewModelScope.launch {
        val model = _state.value.loadCandidate ?: return@launch
        _state.update { it.copy(info = "Loading ${model.displayName}…", loadCandidate = null, hardwareEstimate = null) }
        repo.activateModel(model.id, _state.value.config).onSuccess {
            _state.update { it.copy(info = "${model.displayName} loaded locally.") }
        }.onFailure { e ->
            val suffix = if (model.storageMode == StorageMode.ORIGINAL_URI) "\n\nIf this document provider cannot expose the GGUF reliably to native mmap, import a managed copy instead." else ""
            _state.update { it.copy(error = (e.message ?: "Model load failed.") + suffix, info = null) }
        }
    }

    fun saveCurrentProfile(name: String, systemPromptOverride: String?) {
        val modelId = _state.value.models.firstOrNull { it.active }?.id ?: return
        viewModelScope.launch {
            repo.saveProfile(modelId, name, _state.value.config, systemPromptOverride)
            _state.update { it.copy(info = "Model profile saved locally.") }
        }
    }

    fun activateProfile(profile: ModelProfileEntity) = viewModelScope.launch {
        val config = repo.activateProfile(profile)
        _state.update { it.copy(config = config, info = "Profile ${profile.name} activated. Reload the selected model to apply load-time settings.") }
    }

    fun deleteProfile(profile: ModelProfileEntity) = viewModelScope.launch { repo.deleteProfile(profile) }

    fun unloadModel() = viewModelScope.launch { repo.unloadModel(); _state.update { it.copy(info = "Model unloaded. Story data was preserved.") } }
    fun removeModel(model: ModelDescriptor) = viewModelScope.launch { repo.removeModel(model.id) }
    fun renameModel(model: ModelDescriptor, name: String) = viewModelScope.launch { repo.renameModel(model.id, name) }

    fun addBible(category: String, name: String, content: String) {
        val id = _state.value.currentStory?.id ?: return
        viewModelScope.launch { repo.addBible(id, category, name, content) }
    }
    fun deleteBible(entry: BibleEntryEntity) = viewModelScope.launch { repo.deleteBible(entry) }

    fun createBranch(name: String) {
        val s = _state.value.currentStory ?: return
        viewModelScope.launch { repo.createBranch(s, name); _state.update { it.copy(info = "Branch created from the current story state.") } }
    }
    fun switchBranch(branch: BranchEntity) {
        val s = _state.value.currentStory ?: return
        viewModelScope.launch { repo.switchToBranch(s, branch); selectStory(s.id) }
    }

    fun setConfig(config: ModelLoadConfig) = _state.update { it.copy(config = config) }
    fun toggleAdvanced() = _state.update { it.copy(advancedSettings = !it.advancedSettings) }
    fun setTemplate(kind: PromptTemplateKind) { _state.update { it.copy(template = kind) }; viewModelScope.launch { repo.savePromptTemplate(kind) } }

    fun setGlobalPrompt(value: String) = _state.update { it.copy(globalSystemPrompt = value) }
    fun saveGlobalPrompt() = viewModelScope.launch { repo.saveGlobalSystemPrompt(_state.value.globalSystemPrompt); _state.update { it.copy(info = "Global system prompt saved locally.") } }
    fun resetGlobalPrompt() = viewModelScope.launch { repo.resetGlobalSystemPrompt(); _state.update { it.copy(globalSystemPrompt = repo.globalSystemPrompt()) } }

    fun setStoryPromptOverride(value: String?) {
        val s = _state.value.currentStory ?: return
        val updated = s.copy(systemPromptOverride = value)
        _state.update { it.copy(currentStory = updated) }
        scheduleStorySave(updated)
    }

    fun setCustomTemplate(value: String) = _state.update { it.copy(customTemplate = value) }
    fun saveCustomTemplate() = viewModelScope.launch {
        runCatching { repo.saveCustomTemplate(_state.value.customTemplate) }
            .onSuccess { _state.update { it.copy(info = "Custom prompt template saved.") } }
            .onFailure { e -> _state.update { it.copy(error = e.message) } }
    }

    fun search(query: String) {
        val id = _state.value.currentStory?.id ?: return
        _state.update { it.copy(searchQuery = query) }
        viewModelScope.launch { _state.update { s -> s.copy(searchHits = repo.searchStory(id, query).size) } }
    }

    fun clearMessages() = _state.update { it.copy(error = null, info = null) }
    fun exportText(): String {
        val s = _state.value.currentStory ?: return ""
        return "# ${s.title}\n\n${s.body}"
    }
    fun availableStorage() = repo.availableStorageBytes()

    private fun scheduleStorySave(story: StoryEntity) {
        storySaveJob?.cancel()
        storySaveJob = viewModelScope.launch { delay(350); repo.saveStory(story) }
    }
    private fun pushUndo(text: String) {
        if (undo.lastOrNull() == text) return
        undo.addLast(text)
        while (undo.size > 80) undo.removeFirst()
    }
    fun formatBytes(v: Long): String {
        if (v < 0) return "Unknown"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var n = v.toDouble(); var i = 0
        while (n >= 1024 && i < units.lastIndex) { n /= 1024; i++ }
        return "${DecimalFormat(if (i >= 3) "0.0" else "0.#").format(n)} ${units[i]}"
    }
}
